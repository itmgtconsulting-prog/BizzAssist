# S2S Java reference Client

This repository provides a reference implementation for integrating with the S2S HTTP XML API. It is intended to
supplement official documentation and to demonstrate example solution for:

* HTTP XML API connector integration
* Authentication and security (mTLS with OCES certificates)
* Required configuration for client integration
* Digital signature implementation for XML payloads

## Requirements
* Java 11 or newer
  * You can verify it by running `java -version` in your command line
* Build system
  * Gradle
  * Maven
* System certificate registered in DOMETL for the organisation whitelisting to S2S

## Usage
This reference client enables verification of your connectivity to the S2S HTTP XML API. It includes integration tests to validate successful connection.

>Note:
>
>This repository does not include a valid certificate for connecting to the S2S API.
Please provide your own keystore and truststore to enable mTLS authentication.
All relevant properties must be specified in application.properties within the integrationTests submodule.

Users of the reference client are expected to provide their own XML files. To do so, place the XML files in the src/integrationTest/resources folder in subfolders according to the endpoint being tested, e.g. for ElektroniskAkt BilSoeg place the XML in src/integrationTest/resources/xmlData/ElektroniskAkt/BilSoeg/BilSoeg.xml. Alternatively update the path from which XML is read in the respective integration test located in src/integrationTest/groovy/dk/tinglysning/s2s/reference/client/http/controllers

>Note:
>
>The sample XML files provided are for illustrative purposes only and may result in HTTP 400 responses.

## Building and Testing
### Using Gradle
* Build the project

  `./gradlew build`
* Run unit tests

  `./gradlew test`
* Run integration tests

  `./gradlew integrationTest`

### Using Maven
* Build the project

  `mvn install`
* Run unit tests

  `mvn test`

  or

  `mvn verify`
* Run integration tests

  `mvn integration-test -Pintegration-tests`

  or

  `mvn verify -Pintegration-tests`

## Configuration
Provide your keystore and truststore files for mTLS authentication.
Create application.properties in the integration tests module with the correct paths and passwords for your
certificates. For guidance on the required properties and formatting, please refer to the provided application.properties.dist file.
