plugins {
    java
    groovy
    alias(libs.plugins.lombok)
}

group = "dk.tinglysning.xmlapi"

repositories {
    mavenCentral()
    gradlePluginPortal()
}

tasks.named<JavaCompile>("compileJava") {
    options.release = 11
}

java {
    toolchain {
        languageVersion = JavaLanguageVersion.of(17)
    }

    withSourcesJar()
}

testing {
    @Suppress("UnstableApiUsage")
    suites {
        withType<JvmTestSuite> {
            useJUnitJupiter()
            useSpock(libs.versions.spock)

            dependencies {
                implementation(libs.spock)
                implementation(libs.mockito)
            }
        }

        create<JvmTestSuite>("integrationTest") {
            dependencies {
                implementation(project())
            }
        }

        create<JvmTestSuite>("codeGeneration") {
            dependencies {
                implementation(project())
            }
        }
    }
}

try {
    pluginManager.apply("tinglysning-xmlapi-publish")
} catch (e: Exception) {
    logger.lifecycle("Plugin 'tinglysning-xmlapi-publish' not found, skipping. This part is only used internally and is not needed in the reference client package.")
}