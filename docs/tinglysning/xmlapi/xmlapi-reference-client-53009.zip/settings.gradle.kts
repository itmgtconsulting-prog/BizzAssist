rootProject.name = "s2s-java-reference-client"
