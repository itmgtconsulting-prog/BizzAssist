package dk.tinglysning.xmlapi.reference.client.http.controllers

import dk.tinglysning.xmlapi.reference.client.XmlApiHttpClientFactory
import dk.tinglysning.xmlapi.reference.client.configurations.ApiClientConfiguration
import dk.tinglysning.xmlapi.reference.client.http.AbonnementController
import dk.tinglysning.xmlapi.reference.client.signing.DocumentSigner
import dk.tinglysning.xmlapi.reference.client.signing.StringToDocumentMapper
import org.w3c.dom.Document
import spock.lang.Shared
import spock.lang.Specification
import java.net.http.HttpResponse
import java.util.stream.Collectors

/**
 * This tests are only used to check if you can connect to our service. They were made to allow you to check that
 * successful connection is possible and as a reference usage.
 */
class AbonnementControllerSpec extends Specification {

    @Shared
    static String xmlPayload
    @Shared
    static DocumentSigner documentSigner
    @Shared
    static AbonnementController service

    def setupSpec() {
        def configuration = ApiClientConfiguration.getApiConfigWithAppProperties()

        documentSigner = new DocumentSigner(configuration)

        def xmlApiHttpClient = XmlApiHttpClientFactory.create(configuration)
        service = new  AbonnementController(xmlApiHttpClient)
    }
    

    def "Given all properties, it is possible to make a connection to ETL AbonnementOpret endpoint"() {
        given:
        InputStream is = AbonnementControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/Abonnement/AbonnementOpret/AbonnementOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postAbonnementOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to AbonnementOpret ETL endpoint"() {
        given:
        InputStream is = AbonnementControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/Abonnement/AbonnementOpret/AbonnementOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postAbonnementOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL AbonnementSlet endpoint"() {
        given:
        InputStream is = AbonnementControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/Abonnement/AbonnementSlet/AbonnementSlet.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postAbonnementSlet(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to AbonnementSlet ETL endpoint"() {
        given:
        InputStream is = AbonnementControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/Abonnement/AbonnementSlet/AbonnementSlet.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postAbonnementSlet(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL AbonnementStatus endpoint"() {
        given:
        InputStream is = AbonnementControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/Abonnement/AbonnementStatus/AbonnementStatus.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postAbonnementStatus(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to AbonnementStatus ETL endpoint"() {
        given:
        InputStream is = AbonnementControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/Abonnement/AbonnementStatus/AbonnementStatus.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postAbonnementStatus(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    
}
    