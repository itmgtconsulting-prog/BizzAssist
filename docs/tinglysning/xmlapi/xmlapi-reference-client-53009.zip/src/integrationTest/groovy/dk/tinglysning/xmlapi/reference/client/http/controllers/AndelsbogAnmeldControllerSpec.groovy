package dk.tinglysning.xmlapi.reference.client.http.controllers

import dk.tinglysning.xmlapi.reference.client.XmlApiHttpClientFactory
import dk.tinglysning.xmlapi.reference.client.configurations.ApiClientConfiguration
import dk.tinglysning.xmlapi.reference.client.http.AndelsbogAnmeldController
import dk.tinglysning.xmlapi.reference.client.signing.DocumentSigner
import dk.tinglysning.xmlapi.reference.client.signing.StringToDocumentMapper
import org.w3c.dom.Document
import spock.lang.Shared
import spock.lang.Specification
import java.net.http.HttpResponse
import java.util.stream.Collectors

/**
 * This tests are only used to check if you can connect to our service. They were made to allow you to check that
 * successful connection is possible and as a reference usage.
 */
class AndelsbogAnmeldControllerSpec extends Specification {

    @Shared
    static String xmlPayload
    @Shared
    static DocumentSigner documentSigner
    @Shared
    static AndelsbogAnmeldController service

    def setupSpec() {
        def configuration = ApiClientConfiguration.getApiConfigWithAppProperties()

        documentSigner = new DocumentSigner(configuration)

        def xmlApiHttpClient = XmlApiHttpClientFactory.create(configuration)
        service = new  AndelsbogAnmeldController(xmlApiHttpClient)
    }
    

    def "Given all properties, it is possible to make a connection to ETL AfgiftPantebrevPaategn endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/AfgiftPantebrevPaategn/AfgiftPantebrevPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postAfgiftPantebrevPaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to AfgiftPantebrevPaategn ETL endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/AfgiftPantebrevPaategn/AfgiftPantebrevPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postAfgiftPantebrevPaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL ArrestAndelOpret endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/ArrestAndelOpret/ArrestAndelOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postArrestAndelOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to ArrestAndelOpret ETL endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/ArrestAndelOpret/ArrestAndelOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postArrestAndelOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL DigitaliserPantebrevAndelPaategn endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/DigitaliserPantebrevAndelPaategn/DigitaliserPantebrevAndelPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postDigitaliserPantebrevAndelPaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to DigitaliserPantebrevAndelPaategn ETL endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/DigitaliserPantebrevAndelPaategn/DigitaliserPantebrevAndelPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postDigitaliserPantebrevAndelPaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL DokumentAfgiftPaategn endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/DokumentAfgiftPaategn/DokumentAfgiftPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postDokumentAfgiftPaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to DokumentAfgiftPaategn ETL endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/DokumentAfgiftPaategn/DokumentAfgiftPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postDokumentAfgiftPaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL OmdannelseTilAfgiftsPantebrevPaategn endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/OmdannelseTilAfgiftsPantebrevPaategn/OmdannelseTilAfgiftsPantebrevPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postOmdannelseTilAfgiftsPantebrevPaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to OmdannelseTilAfgiftsPantebrevPaategn ETL endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/OmdannelseTilAfgiftsPantebrevPaategn/OmdannelseTilAfgiftsPantebrevPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postOmdannelseTilAfgiftsPantebrevPaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL DokumentPaategn endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/DokumentPaategn/DokumentPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postDokumentPaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to DokumentPaategn ETL endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/DokumentPaategn/DokumentPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postDokumentPaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL DokumentSamlingAflys endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/DokumentSamlingAflys/DokumentSamlingAflys.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postDokumentSamlingAflys(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to DokumentSamlingAflys ETL endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/DokumentSamlingAflys/DokumentSamlingAflys.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postDokumentSamlingAflys(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL DokumentRettighedSamlingRelakser endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/DokumentRettighedSamlingRelakser/DokumentRettighedSamlingRelakser.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postDokumentRettighedSamlingRelakser(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to DokumentRettighedSamlingRelakser ETL endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/DokumentRettighedSamlingRelakser/DokumentRettighedSamlingRelakser.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postDokumentRettighedSamlingRelakser(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL EjerpantebrevAndelOpret endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/EjerpantebrevAndelOpret/EjerpantebrevAndelOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postEjerpantebrevAndelOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to EjerpantebrevAndelOpret ETL endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/EjerpantebrevAndelOpret/EjerpantebrevAndelOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postEjerpantebrevAndelOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL FuldmagtAndelOpret endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/FuldmagtAndelOpret/FuldmagtAndelOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postFuldmagtAndelOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to FuldmagtAndelOpret ETL endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/FuldmagtAndelOpret/FuldmagtAndelOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postFuldmagtAndelOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL FuldmagtAndelTilbagekald endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/FuldmagtAndelTilbagekald/FuldmagtAndelTilbagekald.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postFuldmagtAndelTilbagekald(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to FuldmagtAndelTilbagekald ETL endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/FuldmagtAndelTilbagekald/FuldmagtAndelTilbagekald.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postFuldmagtAndelTilbagekald(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL HaeftelseKombinationAndelPaategn endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/HaeftelseKombinationAndelPaategn/HaeftelseKombinationAndelPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postHaeftelseKombinationAndelPaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to HaeftelseKombinationAndelPaategn ETL endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/HaeftelseKombinationAndelPaategn/HaeftelseKombinationAndelPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postHaeftelseKombinationAndelPaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL MeddelelseOffentligAndelOpret endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/MeddelelseOffentligAndelOpret/MeddelelseOffentligAndelOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postMeddelelseOffentligAndelOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to MeddelelseOffentligAndelOpret ETL endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/MeddelelseOffentligAndelOpret/MeddelelseOffentligAndelOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postMeddelelseOffentligAndelOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL MeddelelseOffentligPaategn endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/MeddelelseOffentligPaategn/MeddelelseOffentligPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postMeddelelseOffentligPaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to MeddelelseOffentligPaategn ETL endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/MeddelelseOffentligPaategn/MeddelelseOffentligPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postMeddelelseOffentligPaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL PantebrevAndelOpret endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/PantebrevAndelOpret/PantebrevAndelOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postPantebrevAndelOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to PantebrevAndelOpret ETL endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/PantebrevAndelOpret/PantebrevAndelOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postPantebrevAndelOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL SkadesloesbrevAndelOpret endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/SkadesloesbrevAndelOpret/SkadesloesbrevAndelOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postSkadesloesbrevAndelOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to SkadesloesbrevAndelOpret ETL endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/SkadesloesbrevAndelOpret/SkadesloesbrevAndelOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postSkadesloesbrevAndelOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL UdlaegAndelOpret endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/UdlaegAndelOpret/UdlaegAndelOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postUdlaegAndelOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to UdlaegAndelOpret ETL endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/UdlaegAndelOpret/UdlaegAndelOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postUdlaegAndelOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL UnderpantsaetningAndelOpret endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/UnderpantsaetningAndelOpret/UnderpantsaetningAndelOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postUnderpantsaetningAndelOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to UnderpantsaetningAndelOpret ETL endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/UnderpantsaetningAndelOpret/UnderpantsaetningAndelOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postUnderpantsaetningAndelOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL UnderpantsaetningAndelPaategn endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/UnderpantsaetningAndelPaategn/UnderpantsaetningAndelPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postUnderpantsaetningAndelPaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to UnderpantsaetningAndelPaategn ETL endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/UnderpantsaetningAndelPaategn/UnderpantsaetningAndelPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postUnderpantsaetningAndelPaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL DokumentAdkomstErklaering endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/DokumentAdkomstErklaering/DokumentAdkomstErklaering.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postDokumentAdkomstErklaering(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to DokumentAdkomstErklaering ETL endpoint"() {
        given:
        InputStream is = AndelsbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/AndelsbogAnmeld/DokumentAdkomstErklaering/DokumentAdkomstErklaering.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postDokumentAdkomstErklaering(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    
}
    