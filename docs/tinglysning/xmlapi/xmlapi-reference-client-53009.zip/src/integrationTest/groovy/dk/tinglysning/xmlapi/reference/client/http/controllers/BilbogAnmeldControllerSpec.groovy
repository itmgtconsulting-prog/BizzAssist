package dk.tinglysning.xmlapi.reference.client.http.controllers

import dk.tinglysning.xmlapi.reference.client.XmlApiHttpClientFactory
import dk.tinglysning.xmlapi.reference.client.configurations.ApiClientConfiguration
import dk.tinglysning.xmlapi.reference.client.http.BilbogAnmeldController
import dk.tinglysning.xmlapi.reference.client.signing.DocumentSigner
import dk.tinglysning.xmlapi.reference.client.signing.StringToDocumentMapper
import org.w3c.dom.Document
import spock.lang.Shared
import spock.lang.Specification
import java.net.http.HttpResponse
import java.util.stream.Collectors

/**
 * This tests are only used to check if you can connect to our service. They were made to allow you to check that
 * successful connection is possible and as a reference usage.
 */
class BilbogAnmeldControllerSpec extends Specification {

    @Shared
    static String xmlPayload
    @Shared
    static DocumentSigner documentSigner
    @Shared
    static BilbogAnmeldController service

    def setupSpec() {
        def configuration = ApiClientConfiguration.getApiConfigWithAppProperties()

        documentSigner = new DocumentSigner(configuration)

        def xmlApiHttpClient = XmlApiHttpClientFactory.create(configuration)
        service = new  BilbogAnmeldController(xmlApiHttpClient)
    }
    

    def "Given all properties, it is possible to make a connection to ETL ArrestBilOpret endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/ArrestBilOpret/ArrestBilOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postArrestBilOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to ArrestBilOpret ETL endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/ArrestBilOpret/ArrestBilOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postArrestBilOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL DigitaliserPantebrevBilPaategn endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/DigitaliserPantebrevBilPaategn/DigitaliserPantebrevBilPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postDigitaliserPantebrevBilPaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to DigitaliserPantebrevBilPaategn ETL endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/DigitaliserPantebrevBilPaategn/DigitaliserPantebrevBilPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postDigitaliserPantebrevBilPaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL DokumentAfgiftPaategn endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/DokumentAfgiftPaategn/DokumentAfgiftPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postDokumentAfgiftPaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to DokumentAfgiftPaategn ETL endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/DokumentAfgiftPaategn/DokumentAfgiftPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postDokumentAfgiftPaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL DokumentPaategn endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/DokumentPaategn/DokumentPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postDokumentPaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to DokumentPaategn ETL endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/DokumentPaategn/DokumentPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postDokumentPaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL DokumentSamlingAflys endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/DokumentSamlingAflys/DokumentSamlingAflys.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postDokumentSamlingAflys(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to DokumentSamlingAflys ETL endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/DokumentSamlingAflys/DokumentSamlingAflys.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postDokumentSamlingAflys(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL DokumentRettighedSamlingRelakser endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/DokumentRettighedSamlingRelakser/DokumentRettighedSamlingRelakser.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postDokumentRettighedSamlingRelakser(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to DokumentRettighedSamlingRelakser ETL endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/DokumentRettighedSamlingRelakser/DokumentRettighedSamlingRelakser.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postDokumentRettighedSamlingRelakser(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL EjendomsforbeholdBilOpret endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/EjendomsforbeholdBilOpret/EjendomsforbeholdBilOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postEjendomsforbeholdBilOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to EjendomsforbeholdBilOpret ETL endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/EjendomsforbeholdBilOpret/EjendomsforbeholdBilOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postEjendomsforbeholdBilOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL EjerpantebrevBilOpret endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/EjerpantebrevBilOpret/EjerpantebrevBilOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postEjerpantebrevBilOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to EjerpantebrevBilOpret ETL endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/EjerpantebrevBilOpret/EjerpantebrevBilOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postEjerpantebrevBilOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL FuldmagtBilOpret endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/FuldmagtBilOpret/FuldmagtBilOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postFuldmagtBilOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to FuldmagtBilOpret ETL endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/FuldmagtBilOpret/FuldmagtBilOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postFuldmagtBilOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL FuldmagtBilTilbagekald endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/FuldmagtBilTilbagekald/FuldmagtBilTilbagekald.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postFuldmagtBilTilbagekald(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to FuldmagtBilTilbagekald ETL endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/FuldmagtBilTilbagekald/FuldmagtBilTilbagekald.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postFuldmagtBilTilbagekald(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL HaeftelseKombinationBilPaategn endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/HaeftelseKombinationBilPaategn/HaeftelseKombinationBilPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postHaeftelseKombinationBilPaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to HaeftelseKombinationBilPaategn ETL endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/HaeftelseKombinationBilPaategn/HaeftelseKombinationBilPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postHaeftelseKombinationBilPaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL MeddelelseOffentligBilOpret endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/MeddelelseOffentligBilOpret/MeddelelseOffentligBilOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postMeddelelseOffentligBilOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to MeddelelseOffentligBilOpret ETL endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/MeddelelseOffentligBilOpret/MeddelelseOffentligBilOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postMeddelelseOffentligBilOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL MeddelelseOffentligPaategn endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/MeddelelseOffentligPaategn/MeddelelseOffentligPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postMeddelelseOffentligPaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to MeddelelseOffentligPaategn ETL endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/MeddelelseOffentligPaategn/MeddelelseOffentligPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postMeddelelseOffentligPaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL PantebrevBilOpret endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/PantebrevBilOpret/PantebrevBilOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postPantebrevBilOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to PantebrevBilOpret ETL endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/PantebrevBilOpret/PantebrevBilOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postPantebrevBilOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL SkadesloesbrevBilOpret endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/SkadesloesbrevBilOpret/SkadesloesbrevBilOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postSkadesloesbrevBilOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to SkadesloesbrevBilOpret ETL endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/SkadesloesbrevBilOpret/SkadesloesbrevBilOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postSkadesloesbrevBilOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL UdlaegBilOpret endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/UdlaegBilOpret/UdlaegBilOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postUdlaegBilOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to UdlaegBilOpret ETL endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/UdlaegBilOpret/UdlaegBilOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postUdlaegBilOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL UnderpantsaetningBilOpret endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/UnderpantsaetningBilOpret/UnderpantsaetningBilOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postUnderpantsaetningBilOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to UnderpantsaetningBilOpret ETL endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/UnderpantsaetningBilOpret/UnderpantsaetningBilOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postUnderpantsaetningBilOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL UnderpantsaetningBilPaategn endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/UnderpantsaetningBilPaategn/UnderpantsaetningBilPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postUnderpantsaetningBilPaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to UnderpantsaetningBilPaategn ETL endpoint"() {
        given:
        InputStream is = BilbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/BilbogAnmeld/UnderpantsaetningBilPaategn/UnderpantsaetningBilPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postUnderpantsaetningBilPaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    
}
    