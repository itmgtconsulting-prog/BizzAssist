package dk.tinglysning.xmlapi.reference.client.http.controllers

import dk.tinglysning.xmlapi.reference.client.XmlApiHttpClientFactory
import dk.tinglysning.xmlapi.reference.client.configurations.ApiClientConfiguration
import dk.tinglysning.xmlapi.reference.client.http.BrugerformularController
import dk.tinglysning.xmlapi.reference.client.signing.DocumentSigner
import dk.tinglysning.xmlapi.reference.client.signing.StringToDocumentMapper
import org.w3c.dom.Document
import spock.lang.Shared
import spock.lang.Specification
import java.net.http.HttpResponse
import java.util.stream.Collectors

/**
 * This tests are only used to check if you can connect to our service. They were made to allow you to check that
 * successful connection is possible and as a reference usage.
 */
class BrugerformularControllerSpec extends Specification {

    @Shared
    static String xmlPayload
    @Shared
    static DocumentSigner documentSigner
    @Shared
    static BrugerformularController service

    def setupSpec() {
        def configuration = ApiClientConfiguration.getApiConfigWithAppProperties()

        documentSigner = new DocumentSigner(configuration)

        def xmlApiHttpClient = XmlApiHttpClientFactory.create(configuration)
        service = new  BrugerformularController(xmlApiHttpClient)
    }
    

    def "Given all properties, it is possible to make a connection to ETL BrugerformularHent endpoint"() {
        given:
        InputStream is = BrugerformularControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/Brugerformular/BrugerformularHent/BrugerformularHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postBrugerformularHent(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to BrugerformularHent ETL endpoint"() {
        given:
        InputStream is = BrugerformularControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/Brugerformular/BrugerformularHent/BrugerformularHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postBrugerformularHent(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL BrugerformularIndsend endpoint"() {
        given:
        InputStream is = BrugerformularControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/Brugerformular/BrugerformularIndsend/BrugerformularIndsend.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postBrugerformularIndsend(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to BrugerformularIndsend ETL endpoint"() {
        given:
        InputStream is = BrugerformularControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/Brugerformular/BrugerformularIndsend/BrugerformularIndsend.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postBrugerformularIndsend(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL BrugerformularOpdater endpoint"() {
        given:
        InputStream is = BrugerformularControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/Brugerformular/BrugerformularOpdater/BrugerformularOpdater.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postBrugerformularOpdater(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to BrugerformularOpdater ETL endpoint"() {
        given:
        InputStream is = BrugerformularControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/Brugerformular/BrugerformularOpdater/BrugerformularOpdater.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postBrugerformularOpdater(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL BrugerformularSoeg endpoint"() {
        given:
        InputStream is = BrugerformularControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/Brugerformular/BrugerformularSoeg/BrugerformularSoeg.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postBrugerformularSoeg(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to BrugerformularSoeg ETL endpoint"() {
        given:
        InputStream is = BrugerformularControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/Brugerformular/BrugerformularSoeg/BrugerformularSoeg.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postBrugerformularSoeg(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    
}
    