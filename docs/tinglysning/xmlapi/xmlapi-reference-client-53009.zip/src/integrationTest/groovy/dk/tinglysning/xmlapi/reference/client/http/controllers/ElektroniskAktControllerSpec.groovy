package dk.tinglysning.xmlapi.reference.client.http.controllers

import dk.tinglysning.xmlapi.reference.client.XmlApiHttpClientFactory
import dk.tinglysning.xmlapi.reference.client.configurations.ApiClientConfiguration
import dk.tinglysning.xmlapi.reference.client.http.ElektroniskAktController
import dk.tinglysning.xmlapi.reference.client.signing.DocumentSigner
import dk.tinglysning.xmlapi.reference.client.signing.StringToDocumentMapper
import org.w3c.dom.Document
import spock.lang.Shared
import spock.lang.Specification
import java.net.http.HttpResponse
import java.util.stream.Collectors

/**
 * This tests are only used to check if you can connect to our service. They were made to allow you to check that
 * successful connection is possible and as a reference usage.
 */
class ElektroniskAktControllerSpec extends Specification {

    @Shared
    static String xmlPayload
    @Shared
    static DocumentSigner documentSigner
    @Shared
    static ElektroniskAktController service

    def setupSpec() {
        def configuration = ApiClientConfiguration.getApiConfigWithAppProperties()

        documentSigner = new DocumentSigner(configuration)

        def xmlApiHttpClient = XmlApiHttpClientFactory.create(configuration)
        service = new  ElektroniskAktController(xmlApiHttpClient)
    }
    

    def "Given all properties, it is possible to make a connection to ETL SenesteAendringTinglysningsobjektHent endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/SenesteAendringTinglysningsobjektHent/SenesteAendringTinglysningsobjektHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postSenesteAendringTinglysningsobjektHent(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to SenesteAendringTinglysningsobjektHent ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/SenesteAendringTinglysningsobjektHent/SenesteAendringTinglysningsobjektHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postSenesteAendringTinglysningsobjektHent(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL AendredeTinglysningsobjekterHent endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/AendredeTinglysningsobjekterHent/AendredeTinglysningsobjekterHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postAendredeTinglysningsobjekterHent(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to AendredeTinglysningsobjekterHent ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/AendredeTinglysningsobjekterHent/AendredeTinglysningsobjekterHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postAendredeTinglysningsobjekterHent(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL AliasSoeg endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/AliasSoeg/AliasSoeg.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postAliasSoeg(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to AliasSoeg ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/AliasSoeg/AliasSoeg.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postAliasSoeg(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL AndelsbogDokumentAktuelHent endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/AndelsbogDokumentAktuelHent/AndelsbogDokumentAktuelHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postAndelsbogDokumentAktuelHent(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to AndelsbogDokumentAktuelHent ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/AndelsbogDokumentAktuelHent/AndelsbogDokumentAktuelHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postAndelsbogDokumentAktuelHent(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL AndelsbogDokumentRevisionssporHent endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/AndelsbogDokumentRevisionssporHent/AndelsbogDokumentRevisionssporHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postAndelsbogDokumentRevisionssporHent(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to AndelsbogDokumentRevisionssporHent ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/AndelsbogDokumentRevisionssporHent/AndelsbogDokumentRevisionssporHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postAndelsbogDokumentRevisionssporHent(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL AndelSoeg endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/AndelSoeg/AndelSoeg.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postAndelSoeg(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to AndelSoeg ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/AndelSoeg/AndelSoeg.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postAndelSoeg(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL AndelSummariskHent endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/AndelSummariskHent/AndelSummariskHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postAndelSummariskHent(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to AndelSummariskHent ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/AndelSummariskHent/AndelSummariskHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postAndelSummariskHent(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL BilbogDokumentAktuelHent endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/BilbogDokumentAktuelHent/BilbogDokumentAktuelHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postBilbogDokumentAktuelHent(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to BilbogDokumentAktuelHent ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/BilbogDokumentAktuelHent/BilbogDokumentAktuelHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postBilbogDokumentAktuelHent(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL BilbogDokumentRevisionssporHent endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/BilbogDokumentRevisionssporHent/BilbogDokumentRevisionssporHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postBilbogDokumentRevisionssporHent(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to BilbogDokumentRevisionssporHent ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/BilbogDokumentRevisionssporHent/BilbogDokumentRevisionssporHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postBilbogDokumentRevisionssporHent(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL BilSoeg endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/BilSoeg/BilSoeg.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postBilSoeg(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to BilSoeg ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/BilSoeg/BilSoeg.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postBilSoeg(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL BilSummariskHent endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/BilSummariskHent/BilSummariskHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postBilSummariskHent(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to BilSummariskHent ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/BilSummariskHent/BilSummariskHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postBilSummariskHent(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL DokumentAktuelHent endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/DokumentAktuelHent/DokumentAktuelHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postDokumentAktuelHent(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to DokumentAktuelHent ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/DokumentAktuelHent/DokumentAktuelHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postDokumentAktuelHent(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL DokumentTinglysningsobjekterHent endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/DokumentTinglysningsobjekterHent/DokumentTinglysningsobjekterHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postDokumentTinglysningsobjekterHent(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to DokumentTinglysningsobjekterHent ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/DokumentTinglysningsobjekterHent/DokumentTinglysningsobjekterHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postDokumentTinglysningsobjekterHent(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL DokumentRevisionssporHent endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/DokumentRevisionssporHent/DokumentRevisionssporHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postDokumentRevisionssporHent(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to DokumentRevisionssporHent ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/DokumentRevisionssporHent/DokumentRevisionssporHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postDokumentRevisionssporHent(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL EjendomAdkomsterHent endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/EjendomAdkomsterHent/EjendomAdkomsterHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postEjendomAdkomsterHent(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to EjendomAdkomsterHent ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/EjendomAdkomsterHent/EjendomAdkomsterHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postEjendomAdkomsterHent(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL EjendomHistoriskAdkomsterHent endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/EjendomHistoriskAdkomsterHent/EjendomHistoriskAdkomsterHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postEjendomHistoriskAdkomsterHent(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to EjendomHistoriskAdkomsterHent ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/EjendomHistoriskAdkomsterHent/EjendomHistoriskAdkomsterHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postEjendomHistoriskAdkomsterHent(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL EjendomHaeftelserHent endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/EjendomHaeftelserHent/EjendomHaeftelserHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postEjendomHaeftelserHent(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to EjendomHaeftelserHent ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/EjendomHaeftelserHent/EjendomHaeftelserHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postEjendomHaeftelserHent(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL EjendomIndskannetAktHent endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/EjendomIndskannetAktHent/EjendomIndskannetAktHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postEjendomIndskannetAktHent(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to EjendomIndskannetAktHent ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/EjendomIndskannetAktHent/EjendomIndskannetAktHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postEjendomIndskannetAktHent(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL EjendomServitutterHent endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/EjendomServitutterHent/EjendomServitutterHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postEjendomServitutterHent(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to EjendomServitutterHent ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/EjendomServitutterHent/EjendomServitutterHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postEjendomServitutterHent(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL EjendomSoeg endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/EjendomSoeg/EjendomSoeg.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postEjendomSoeg(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to EjendomSoeg ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/EjendomSoeg/EjendomSoeg.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postEjendomSoeg(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL EjendomStamoplysningerHent endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/EjendomStamoplysningerHent/EjendomStamoplysningerHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postEjendomStamoplysningerHent(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to EjendomStamoplysningerHent ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/EjendomStamoplysningerHent/EjendomStamoplysningerHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postEjendomStamoplysningerHent(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL EjendomSummariskHent endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/EjendomSummariskHent/EjendomSummariskHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postEjendomSummariskHent(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to EjendomSummariskHent ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/EjendomSummariskHent/EjendomSummariskHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postEjendomSummariskHent(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL EjendomUdskriftBestil endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/EjendomUdskriftBestil/EjendomUdskriftBestil.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postEjendomUdskriftBestil(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to EjendomUdskriftBestil ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/EjendomUdskriftBestil/EjendomUdskriftBestil.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postEjendomUdskriftBestil(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL FuldmagtAndelSoeg endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/FuldmagtAndelSoeg/FuldmagtAndelSoeg.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postFuldmagtAndelSoeg(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to FuldmagtAndelSoeg ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/FuldmagtAndelSoeg/FuldmagtAndelSoeg.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postFuldmagtAndelSoeg(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL FuldmagtBilSoeg endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/FuldmagtBilSoeg/FuldmagtBilSoeg.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postFuldmagtBilSoeg(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to FuldmagtBilSoeg ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/FuldmagtBilSoeg/FuldmagtBilSoeg.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postFuldmagtBilSoeg(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL FuldmagtFastEjendomSoeg endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/FuldmagtFastEjendomSoeg/FuldmagtFastEjendomSoeg.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postFuldmagtFastEjendomSoeg(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to FuldmagtFastEjendomSoeg ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/FuldmagtFastEjendomSoeg/FuldmagtFastEjendomSoeg.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postFuldmagtFastEjendomSoeg(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL FuldmagtLoesoereSoeg endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/FuldmagtLoesoereSoeg/FuldmagtLoesoereSoeg.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postFuldmagtLoesoereSoeg(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to FuldmagtLoesoereSoeg ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/FuldmagtLoesoereSoeg/FuldmagtLoesoereSoeg.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postFuldmagtLoesoereSoeg(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL LoesoereSoeg endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/LoesoereSoeg/LoesoereSoeg.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postLoesoereSoeg(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to LoesoereSoeg ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/LoesoereSoeg/LoesoereSoeg.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postLoesoereSoeg(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL LoesoereSummariskHent endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/LoesoereSummariskHent/LoesoereSummariskHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postLoesoereSummariskHent(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to LoesoereSummariskHent ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/LoesoereSummariskHent/LoesoereSummariskHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postLoesoereSummariskHent(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL PersonbogDokumentAktuelHent endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/PersonbogDokumentAktuelHent/PersonbogDokumentAktuelHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postPersonbogDokumentAktuelHent(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to PersonbogDokumentAktuelHent ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/PersonbogDokumentAktuelHent/PersonbogDokumentAktuelHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postPersonbogDokumentAktuelHent(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL PersonbogDokumentRevisionssporHent endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/PersonbogDokumentRevisionssporHent/PersonbogDokumentRevisionssporHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postPersonbogDokumentRevisionssporHent(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to PersonbogDokumentRevisionssporHent ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/PersonbogDokumentRevisionssporHent/PersonbogDokumentRevisionssporHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postPersonbogDokumentRevisionssporHent(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL PersondokumentSummariskHent endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/PersondokumentSummariskHent/PersondokumentSummariskHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postPersondokumentSummariskHent(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to PersondokumentSummariskHent ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/PersondokumentSummariskHent/PersondokumentSummariskHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postPersondokumentSummariskHent(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL PersondokumentSkifteretHent endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/PersondokumentSkifteretHent/PersondokumentSkifteretHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postPersondokumentSkifteretHent(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to PersondokumentSkifteretHent ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/PersondokumentSkifteretHent/PersondokumentSkifteretHent.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postPersondokumentSkifteretHent(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL UdskriftBestil endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/UdskriftBestil/UdskriftBestil.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postUdskriftBestil(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to UdskriftBestil ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/UdskriftBestil/UdskriftBestil.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postUdskriftBestil(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL VirksomhedSoeg endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/VirksomhedSoeg/VirksomhedSoeg.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postVirksomhedSoeg(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to VirksomhedSoeg ETL endpoint"() {
        given:
        InputStream is = ElektroniskAktControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/ElektroniskAkt/VirksomhedSoeg/VirksomhedSoeg.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postVirksomhedSoeg(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    
}
    