package dk.tinglysning.xmlapi.reference.client.http.controllers

import dk.tinglysning.xmlapi.reference.client.XmlApiHttpClientFactory
import dk.tinglysning.xmlapi.reference.client.configurations.ApiClientConfiguration
import dk.tinglysning.xmlapi.reference.client.http.PersonbogAnmeldController
import dk.tinglysning.xmlapi.reference.client.signing.DocumentSigner
import dk.tinglysning.xmlapi.reference.client.signing.StringToDocumentMapper
import org.w3c.dom.Document
import spock.lang.Shared
import spock.lang.Specification
import java.net.http.HttpResponse
import java.util.stream.Collectors

/**
 * This tests are only used to check if you can connect to our service. They were made to allow you to check that
 * successful connection is possible and as a reference usage.
 */
class PersonbogAnmeldControllerSpec extends Specification {

    @Shared
    static String xmlPayload
    @Shared
    static DocumentSigner documentSigner
    @Shared
    static PersonbogAnmeldController service

    def setupSpec() {
        def configuration = ApiClientConfiguration.getApiConfigWithAppProperties()

        documentSigner = new DocumentSigner(configuration)

        def xmlApiHttpClient = XmlApiHttpClientFactory.create(configuration)
        service = new  PersonbogAnmeldController(xmlApiHttpClient)
    }
    

    def "Given all properties, it is possible to make a connection to ETL DigitaliserPantebrevLoesoerePaategn endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/DigitaliserPantebrevLoesoerePaategn/DigitaliserPantebrevLoesoerePaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postDigitaliserPantebrevLoesoerePaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to DigitaliserPantebrevLoesoerePaategn ETL endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/DigitaliserPantebrevLoesoerePaategn/DigitaliserPantebrevLoesoerePaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postDigitaliserPantebrevLoesoerePaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL DokumentAfgiftPaategn endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/DokumentAfgiftPaategn/DokumentAfgiftPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postDokumentAfgiftPaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to DokumentAfgiftPaategn ETL endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/DokumentAfgiftPaategn/DokumentAfgiftPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postDokumentAfgiftPaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL DokumentPaategn endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/DokumentPaategn/DokumentPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postDokumentPaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to DokumentPaategn ETL endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/DokumentPaategn/DokumentPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postDokumentPaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL DokumentSamlingAflys endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/DokumentSamlingAflys/DokumentSamlingAflys.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postDokumentSamlingAflys(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to DokumentSamlingAflys ETL endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/DokumentSamlingAflys/DokumentSamlingAflys.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postDokumentSamlingAflys(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL DokumentRettighedSamlingRelakser endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/DokumentRettighedSamlingRelakser/DokumentRettighedSamlingRelakser.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postDokumentRettighedSamlingRelakser(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to DokumentRettighedSamlingRelakser ETL endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/DokumentRettighedSamlingRelakser/DokumentRettighedSamlingRelakser.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postDokumentRettighedSamlingRelakser(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL EjerpantebrevLoesoereOpret endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/EjerpantebrevLoesoereOpret/EjerpantebrevLoesoereOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postEjerpantebrevLoesoereOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to EjerpantebrevLoesoereOpret ETL endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/EjerpantebrevLoesoereOpret/EjerpantebrevLoesoereOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postEjerpantebrevLoesoereOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL EjerpantebrevVirksomhedspantOpret endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/EjerpantebrevVirksomhedspantOpret/EjerpantebrevVirksomhedspantOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postEjerpantebrevVirksomhedspantOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to EjerpantebrevVirksomhedspantOpret ETL endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/EjerpantebrevVirksomhedspantOpret/EjerpantebrevVirksomhedspantOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postEjerpantebrevVirksomhedspantOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL FuldmagtLoesoereOpret endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/FuldmagtLoesoereOpret/FuldmagtLoesoereOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postFuldmagtLoesoereOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to FuldmagtLoesoereOpret ETL endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/FuldmagtLoesoereOpret/FuldmagtLoesoereOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postFuldmagtLoesoereOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL FuldmagtLoesoereTilbagekald endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/FuldmagtLoesoereTilbagekald/FuldmagtLoesoereTilbagekald.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postFuldmagtLoesoereTilbagekald(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to FuldmagtLoesoereTilbagekald ETL endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/FuldmagtLoesoereTilbagekald/FuldmagtLoesoereTilbagekald.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postFuldmagtLoesoereTilbagekald(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL HaeftelseKombinationLoesoerePaategn endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/HaeftelseKombinationLoesoerePaategn/HaeftelseKombinationLoesoerePaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postHaeftelseKombinationLoesoerePaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to HaeftelseKombinationLoesoerePaategn ETL endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/HaeftelseKombinationLoesoerePaategn/HaeftelseKombinationLoesoerePaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postHaeftelseKombinationLoesoerePaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL HoestpantebrevOpret endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/HoestpantebrevOpret/HoestpantebrevOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postHoestpantebrevOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to HoestpantebrevOpret ETL endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/HoestpantebrevOpret/HoestpantebrevOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postHoestpantebrevOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL MeddelelseOffentligPaategn endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/MeddelelseOffentligPaategn/MeddelelseOffentligPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postMeddelelseOffentligPaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to MeddelelseOffentligPaategn ETL endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/MeddelelseOffentligPaategn/MeddelelseOffentligPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postMeddelelseOffentligPaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL PantebrevLoesoereOpret endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/PantebrevLoesoereOpret/PantebrevLoesoereOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postPantebrevLoesoereOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to PantebrevLoesoereOpret ETL endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/PantebrevLoesoereOpret/PantebrevLoesoereOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postPantebrevLoesoereOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL PantsaetningsforbudLoesoereOpret endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/PantsaetningsforbudLoesoereOpret/PantsaetningsforbudLoesoereOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postPantsaetningsforbudLoesoereOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to PantsaetningsforbudLoesoereOpret ETL endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/PantsaetningsforbudLoesoereOpret/PantsaetningsforbudLoesoereOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postPantsaetningsforbudLoesoereOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL SkadesloesbrevLoesoereOpret endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/SkadesloesbrevLoesoereOpret/SkadesloesbrevLoesoereOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postSkadesloesbrevLoesoereOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to SkadesloesbrevLoesoereOpret ETL endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/SkadesloesbrevLoesoereOpret/SkadesloesbrevLoesoereOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postSkadesloesbrevLoesoereOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL TinglysningFormueforholdOpret endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/TinglysningFormueforholdOpret/TinglysningFormueforholdOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postTinglysningFormueforholdOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to TinglysningFormueforholdOpret ETL endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/TinglysningFormueforholdOpret/TinglysningFormueforholdOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postTinglysningFormueforholdOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL TinglysningFormueforholdPaategn endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/TinglysningFormueforholdPaategn/TinglysningFormueforholdPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postTinglysningFormueforholdPaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to TinglysningFormueforholdPaategn ETL endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/TinglysningFormueforholdPaategn/TinglysningFormueforholdPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postTinglysningFormueforholdPaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL UnderpantsaetningLoesoereOpret endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/UnderpantsaetningLoesoereOpret/UnderpantsaetningLoesoereOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postUnderpantsaetningLoesoereOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to UnderpantsaetningLoesoereOpret ETL endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/UnderpantsaetningLoesoereOpret/UnderpantsaetningLoesoereOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postUnderpantsaetningLoesoereOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL UnderpantsaetningLoesoerePaategn endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/UnderpantsaetningLoesoerePaategn/UnderpantsaetningLoesoerePaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postUnderpantsaetningLoesoerePaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to UnderpantsaetningLoesoerePaategn ETL endpoint"() {
        given:
        InputStream is = PersonbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/PersonbogAnmeld/UnderpantsaetningLoesoerePaategn/UnderpantsaetningLoesoerePaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postUnderpantsaetningLoesoerePaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    
}
    