package dk.tinglysning.xmlapi.reference.client.http.controllers

import dk.tinglysning.xmlapi.reference.client.XmlApiHttpClientFactory
import dk.tinglysning.xmlapi.reference.client.configurations.ApiClientConfiguration
import dk.tinglysning.xmlapi.reference.client.http.TingbogAnmeldController
import dk.tinglysning.xmlapi.reference.client.signing.DocumentSigner
import dk.tinglysning.xmlapi.reference.client.signing.StringToDocumentMapper
import org.w3c.dom.Document
import spock.lang.Shared
import spock.lang.Specification
import java.net.http.HttpResponse
import java.util.stream.Collectors

/**
 * This tests are only used to check if you can connect to our service. They were made to allow you to check that
 * successful connection is possible and as a reference usage.
 */
class TingbogAnmeldControllerSpec extends Specification {

    @Shared
    static String xmlPayload
    @Shared
    static DocumentSigner documentSigner
    @Shared
    static TingbogAnmeldController service

    def setupSpec() {
        def configuration = ApiClientConfiguration.getApiConfigWithAppProperties()

        documentSigner = new DocumentSigner(configuration)

        def xmlApiHttpClient = XmlApiHttpClientFactory.create(configuration)
        service = new  TingbogAnmeldController(xmlApiHttpClient)
    }
    

    def "Given all properties, it is possible to make a connection to ETL AdkomstKombinationPaategn endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/AdkomstKombinationPaategn/AdkomstKombinationPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postAdkomstKombinationPaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to AdkomstKombinationPaategn ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/AdkomstKombinationPaategn/AdkomstKombinationPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postAdkomstKombinationPaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL AfgiftPantebrevPaategn endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/AfgiftPantebrevPaategn/AfgiftPantebrevPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postAfgiftPantebrevPaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to AfgiftPantebrevPaategn ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/AfgiftPantebrevPaategn/AfgiftPantebrevPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postAfgiftPantebrevPaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL AndenHaeftelseFastEjendomOpret endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/AndenHaeftelseFastEjendomOpret/AndenHaeftelseFastEjendomOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postAndenHaeftelseFastEjendomOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to AndenHaeftelseFastEjendomOpret ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/AndenHaeftelseFastEjendomOpret/AndenHaeftelseFastEjendomOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postAndenHaeftelseFastEjendomOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL ArrestFastEjendomOpret endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/ArrestFastEjendomOpret/ArrestFastEjendomOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postArrestFastEjendomOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to ArrestFastEjendomOpret ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/ArrestFastEjendomOpret/ArrestFastEjendomOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postArrestFastEjendomOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL AttestDommerOpret endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/AttestDommerOpret/AttestDommerOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postAttestDommerOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to AttestDommerOpret ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/AttestDommerOpret/AttestDommerOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postAttestDommerOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL DigitaliserPantebrevFastEjendomPaategn endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/DigitaliserPantebrevFastEjendomPaategn/DigitaliserPantebrevFastEjendomPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postDigitaliserPantebrevFastEjendomPaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to DigitaliserPantebrevFastEjendomPaategn ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/DigitaliserPantebrevFastEjendomPaategn/DigitaliserPantebrevFastEjendomPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postDigitaliserPantebrevFastEjendomPaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL DokumentAfgiftPaategn endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/DokumentAfgiftPaategn/DokumentAfgiftPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postDokumentAfgiftPaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to DokumentAfgiftPaategn ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/DokumentAfgiftPaategn/DokumentAfgiftPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postDokumentAfgiftPaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL OmdannelseTilAfgiftsPantebrevPaategn endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/OmdannelseTilAfgiftsPantebrevPaategn/OmdannelseTilAfgiftsPantebrevPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postOmdannelseTilAfgiftsPantebrevPaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to OmdannelseTilAfgiftsPantebrevPaategn ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/OmdannelseTilAfgiftsPantebrevPaategn/OmdannelseTilAfgiftsPantebrevPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postOmdannelseTilAfgiftsPantebrevPaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL DokumentFastEjendomOpret endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/DokumentFastEjendomOpret/DokumentFastEjendomOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postDokumentFastEjendomOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to DokumentFastEjendomOpret ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/DokumentFastEjendomOpret/DokumentFastEjendomOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postDokumentFastEjendomOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL DokumentPaategn endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/DokumentPaategn/DokumentPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postDokumentPaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to DokumentPaategn ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/DokumentPaategn/DokumentPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postDokumentPaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL DokumentSamlingAflys endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/DokumentSamlingAflys/DokumentSamlingAflys.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postDokumentSamlingAflys(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to DokumentSamlingAflys ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/DokumentSamlingAflys/DokumentSamlingAflys.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postDokumentSamlingAflys(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL DokumentRettighedSamlingRelakser endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/DokumentRettighedSamlingRelakser/DokumentRettighedSamlingRelakser.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postDokumentRettighedSamlingRelakser(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to DokumentRettighedSamlingRelakser ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/DokumentRettighedSamlingRelakser/DokumentRettighedSamlingRelakser.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postDokumentRettighedSamlingRelakser(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL EjendomOpret endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/EjendomOpret/EjendomOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postEjendomOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to EjendomOpret ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/EjendomOpret/EjendomOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postEjendomOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL EjerpantebrevFastEjendomOpret endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/EjerpantebrevFastEjendomOpret/EjerpantebrevFastEjendomOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postEjerpantebrevFastEjendomOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to EjerpantebrevFastEjendomOpret ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/EjerpantebrevFastEjendomOpret/EjerpantebrevFastEjendomOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postEjerpantebrevFastEjendomOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL FuldmagtFastEjendomOpret endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/FuldmagtFastEjendomOpret/FuldmagtFastEjendomOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postFuldmagtFastEjendomOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to FuldmagtFastEjendomOpret ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/FuldmagtFastEjendomOpret/FuldmagtFastEjendomOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postFuldmagtFastEjendomOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL FuldmagtFastEjendomTilbagekald endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/FuldmagtFastEjendomTilbagekald/FuldmagtFastEjendomTilbagekald.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postFuldmagtFastEjendomTilbagekald(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to FuldmagtFastEjendomTilbagekald ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/FuldmagtFastEjendomTilbagekald/FuldmagtFastEjendomTilbagekald.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postFuldmagtFastEjendomTilbagekald(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL HaeftelseKombinationPaategn endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/HaeftelseKombinationPaategn/HaeftelseKombinationPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postHaeftelseKombinationPaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to HaeftelseKombinationPaategn ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/HaeftelseKombinationPaategn/HaeftelseKombinationPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postHaeftelseKombinationPaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL IndekspantebrevFastEjendomOpret endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/IndekspantebrevFastEjendomOpret/IndekspantebrevFastEjendomOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postIndekspantebrevFastEjendomOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to IndekspantebrevFastEjendomOpret ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/IndekspantebrevFastEjendomOpret/IndekspantebrevFastEjendomOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postIndekspantebrevFastEjendomOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL MeddelelseFastEjendomAdkomstPaategn endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/MeddelelseFastEjendomAdkomstPaategn/MeddelelseFastEjendomAdkomstPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postMeddelelseFastEjendomAdkomstPaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to MeddelelseFastEjendomAdkomstPaategn ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/MeddelelseFastEjendomAdkomstPaategn/MeddelelseFastEjendomAdkomstPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postMeddelelseFastEjendomAdkomstPaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL MeddelelseOffentligOpret endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/MeddelelseOffentligOpret/MeddelelseOffentligOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postMeddelelseOffentligOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to MeddelelseOffentligOpret ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/MeddelelseOffentligOpret/MeddelelseOffentligOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postMeddelelseOffentligOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL MeddelelseOffentligPaategn endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/MeddelelseOffentligPaategn/MeddelelseOffentligPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postMeddelelseOffentligPaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to MeddelelseOffentligPaategn ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/MeddelelseOffentligPaategn/MeddelelseOffentligPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postMeddelelseOffentligPaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL PantebrevFastEjendomOpret endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/PantebrevFastEjendomOpret/PantebrevFastEjendomOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postPantebrevFastEjendomOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to PantebrevFastEjendomOpret ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/PantebrevFastEjendomOpret/PantebrevFastEjendomOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postPantebrevFastEjendomOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL RealkreditpantebrevOpret endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/RealkreditpantebrevOpret/RealkreditpantebrevOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postRealkreditpantebrevOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to RealkreditpantebrevOpret ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/RealkreditpantebrevOpret/RealkreditpantebrevOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postRealkreditpantebrevOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL ServitutErklaeringOpret endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/ServitutErklaeringOpret/ServitutErklaeringOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postServitutErklaeringOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to ServitutErklaeringOpret ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/ServitutErklaeringOpret/ServitutErklaeringOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postServitutErklaeringOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL ServitutKombinationPaategn endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/ServitutKombinationPaategn/ServitutKombinationPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postServitutKombinationPaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to ServitutKombinationPaategn ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/ServitutKombinationPaategn/ServitutKombinationPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postServitutKombinationPaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL ServitutOpret endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/ServitutOpret/ServitutOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postServitutOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to ServitutOpret ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/ServitutOpret/ServitutOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postServitutOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL ServitutOevrigeOpret endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/ServitutOevrigeOpret/ServitutOevrigeOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postServitutOevrigeOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to ServitutOevrigeOpret ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/ServitutOevrigeOpret/ServitutOevrigeOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postServitutOevrigeOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL SkadesloesbrevFastEjendomOpret endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/SkadesloesbrevFastEjendomOpret/SkadesloesbrevFastEjendomOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postSkadesloesbrevFastEjendomOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to SkadesloesbrevFastEjendomOpret ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/SkadesloesbrevFastEjendomOpret/SkadesloesbrevFastEjendomOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postSkadesloesbrevFastEjendomOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL SkadesloesbrevEjendomsskatOpret endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/SkadesloesbrevEjendomsskatOpret/SkadesloesbrevEjendomsskatOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postSkadesloesbrevEjendomsskatOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to SkadesloesbrevEjendomsskatOpret ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/SkadesloesbrevEjendomsskatOpret/SkadesloesbrevEjendomsskatOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postSkadesloesbrevEjendomsskatOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL SkifteretsAttestOpret endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/SkifteretsAttestOpret/SkifteretsAttestOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postSkifteretsAttestOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to SkifteretsAttestOpret ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/SkifteretsAttestOpret/SkifteretsAttestOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postSkifteretsAttestOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL SkoedeAuktionOpret endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/SkoedeAuktionOpret/SkoedeAuktionOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postSkoedeAuktionOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to SkoedeAuktionOpret ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/SkoedeAuktionOpret/SkoedeAuktionOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postSkoedeAuktionOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL SkoedeOpret endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/SkoedeOpret/SkoedeOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postSkoedeOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to SkoedeOpret ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/SkoedeOpret/SkoedeOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postSkoedeOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL UdlaegFastEjendomOpret endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/UdlaegFastEjendomOpret/UdlaegFastEjendomOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postUdlaegFastEjendomOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to UdlaegFastEjendomOpret ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/UdlaegFastEjendomOpret/UdlaegFastEjendomOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postUdlaegFastEjendomOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL UnderbladFastEjendomOpret endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/UnderbladFastEjendomOpret/UnderbladFastEjendomOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postUnderbladFastEjendomOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to UnderbladFastEjendomOpret ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/UnderbladFastEjendomOpret/UnderbladFastEjendomOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postUnderbladFastEjendomOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL UnderpantsaetningFastEjendomOpret endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/UnderpantsaetningFastEjendomOpret/UnderpantsaetningFastEjendomOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postUnderpantsaetningFastEjendomOpret(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to UnderpantsaetningFastEjendomOpret ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/UnderpantsaetningFastEjendomOpret/UnderpantsaetningFastEjendomOpret.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postUnderpantsaetningFastEjendomOpret(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL UnderpantsaetningFastEjendomPaategn endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/UnderpantsaetningFastEjendomPaategn/UnderpantsaetningFastEjendomPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postUnderpantsaetningFastEjendomPaategn(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to UnderpantsaetningFastEjendomPaategn ETL endpoint"() {
        given:
        InputStream is = TingbogAnmeldControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/TingbogAnmeld/UnderpantsaetningFastEjendomPaategn/UnderpantsaetningFastEjendomPaategn.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postUnderpantsaetningFastEjendomPaategn(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    
}
    