package dk.tinglysning.xmlapi.reference.client.http.controllers

import dk.tinglysning.xmlapi.reference.client.XmlApiHttpClientFactory
import dk.tinglysning.xmlapi.reference.client.configurations.ApiClientConfiguration
import dk.tinglysning.xmlapi.reference.client.http.UnderskriftsmappeController
import dk.tinglysning.xmlapi.reference.client.signing.DocumentSigner
import dk.tinglysning.xmlapi.reference.client.signing.StringToDocumentMapper
import org.w3c.dom.Document
import spock.lang.Shared
import spock.lang.Specification
import java.net.http.HttpResponse
import java.util.stream.Collectors

/**
 * This tests are only used to check if you can connect to our service. They were made to allow you to check that
 * successful connection is possible and as a reference usage.
 */
class UnderskriftsmappeControllerSpec extends Specification {

    @Shared
    static String xmlPayload
    @Shared
    static DocumentSigner documentSigner
    @Shared
    static UnderskriftsmappeController service

    def setupSpec() {
        def configuration = ApiClientConfiguration.getApiConfigWithAppProperties()

        documentSigner = new DocumentSigner(configuration)

        def xmlApiHttpClient = XmlApiHttpClientFactory.create(configuration)
        service = new  UnderskriftsmappeController(xmlApiHttpClient)
    }
    

    def "Given all properties, it is possible to make a connection to ETL DokumentIndsaet endpoint"() {
        given:
        InputStream is = UnderskriftsmappeControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/Underskriftsmappe/DokumentIndsaet/DokumentIndsaet.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postDokumentIndsaet(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to DokumentIndsaet ETL endpoint"() {
        given:
        InputStream is = UnderskriftsmappeControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/Underskriftsmappe/DokumentIndsaet/DokumentIndsaet.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postDokumentIndsaet(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    

    def "Given all properties, it is possible to make a connection to ETL DokumentHentOgSlet endpoint"() {
        given:
        InputStream is = UnderskriftsmappeControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/Underskriftsmappe/DokumentHentOgSlet/DokumentHentOgSlet.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()
        def relatesTo = "Test"

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)
        
        HttpResponse<String> response = service.postDokumentHentOgSlet(signedXmlPayload, messageId, relatesTo)
        
        then:
        response.statusCode() == 200
    }

    def "Given all properties and no Relates-To header, it is possible to make a connection to DokumentHentOgSlet ETL endpoint"() {
        given:
        InputStream is = UnderskriftsmappeControllerSpec.class.getClassLoader().getResourceAsStream("xmlData/Underskriftsmappe/DokumentHentOgSlet/DokumentHentOgSlet.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))
        def document = StringToDocumentMapper.stringToDocument(xmlPayload)
        def messageId = UUID.randomUUID().toString()

        when:
        documentSigner.addXmlNamespace(document)
        documentSigner.sign(document)
        def signedXmlPayload = StringToDocumentMapper.documentToString(document)

        HttpResponse<String> response = service.postDokumentHentOgSlet(signedXmlPayload, messageId, null)

        then:
        response.statusCode() == 200
    }
    
}
    