package dk.tinglysning.xmlapi.reference.client;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * Provides an overview of all the e-Tinglysning custom headers used in the connection.
 * {@code TINGLYSNING_RELATES_TO} is optional. Both {@code TINGLYSNING_MESSAGE_ID} and {@code CONTENT_TYPE} are
 * required.
 */
@Getter
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class HeaderProvider {
    public static final String TINGLYSNING_MESSAGE_ID = "Tinglysning-Message-ID";
    public static final String TINGLYSNING_RELATES_TO = "Tinglysning-Relates-To";
    public static final String CONTENT_TYPE = "Content-Type";
}
