package dk.tinglysning.xmlapi.reference.client;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import lombok.Getter;

@Getter
public class HeaderValues {
    private final Map<String, String> headers;

    /**
     * Constructs a new {@code HeaderValues} instance with the specified message UUID.
     * The "relatesTo" header is omitted and the content type is set to "application/xml".
     *
     * @param messageUuid the message UUID; must not be {@code null}
     * @throws IllegalArgumentException if {@code messageUuid} is {@code null}
     */
    public HeaderValues(String messageUuid) {
        this(messageUuid, null, "application/xml");
    }

    /**
     * Constructs a new {@code HeaderValues} instance with the specified message UUID and relatesTo header.
     * The content type is set to "application/xml".
     *
     * @param messageUuid the message UUID; must not be {@code null}
     * @param relatesTo   the relatesTo header value; may be {@code null}
     * @throws IllegalArgumentException if {@code messageUuid} is {@code null}
     */
    public HeaderValues(String messageUuid, String relatesTo) {
        this(messageUuid, relatesTo, "application/xml");
    }

    /**
     * Constructs a new {@code HeaderValues} instance with the specified message UUID, relatesTo header, and content type.
     *
     * @param messageUuid the message UUID; must not be {@code null}
     * @param relatesTo   the relatesTo header value; may be {@code null}
     * @param contentType the content type header value; must not be {@code null}
     * @throws IllegalArgumentException if {@code messageUuid} or {@code contentType} is {@code null}
     */
    public HeaderValues(String messageUuid, String relatesTo, String contentType) {
        if (messageUuid == null || contentType == null) {
            throw new IllegalArgumentException("Message uuid and content type must not be null");
        }

        headers = new HashMap<>();
        headers.put(HeaderProvider.TINGLYSNING_MESSAGE_ID, createMessageUuidHeaderValue(messageUuid));
        headers.put(HeaderProvider.CONTENT_TYPE, contentType);

        if (relatesTo != null) {
            headers.put(HeaderProvider.TINGLYSNING_RELATES_TO, relatesTo);
        }
    }

    /**
     * Creates a message UUID header value in the format "uuid:{uuid}".
     *
     * @param messageUuid the message UUID; must be in standard UUID format
     * @return the header value in the format "uuid:{uuid}"
     * @throws IllegalArgumentException if the {@code messageUuid} does not follow the standard format
     */
    private String createMessageUuidHeaderValue(String messageUuid) {
        messageUuid = messageUuid.toLowerCase();

        String parsedUuid = UUID.fromString(messageUuid).toString();
        if (!parsedUuid.equals(messageUuid)) {
            throw new IllegalArgumentException("Message uuid does not follow format "
                    + "[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12} ");
        }

        return String.format("uuid:%s", parsedUuid);
    }
}
