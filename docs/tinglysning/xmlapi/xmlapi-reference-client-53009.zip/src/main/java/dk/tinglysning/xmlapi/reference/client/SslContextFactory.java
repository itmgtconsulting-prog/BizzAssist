package dk.tinglysning.xmlapi.reference.client;

import dk.tinglysning.xmlapi.reference.client.configurations.ApiClientConfiguration;
import java.security.*;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class SslContextFactory {

    /**
     * Creates an {@link SSLContext} with the provided protocol version and certificates.
     *
     * @param configuration the {@link ApiClientConfiguration} object containing SSL protocol information,
     *                      as well as the loaded keystore and truststore
     * @return a configured {@link SSLContext}
     * @throws IllegalStateException if the specified protocol does not exist, an incorrect password is provided
     *         for the keystore, or there are other issues initializing the stores
     */
    public static SSLContext createSslContext(ApiClientConfiguration configuration) {
        try {
            KeyManagerFactory keyManagerFactory =
                    KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
            keyManagerFactory.init(
                    configuration.getSystemKeyStore(),
                    configuration.getSystemKeystorePassword().toCharArray());

            TrustManagerFactory trustManagerFactory =
                    TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            trustManagerFactory.init(configuration.getTrustStore());

            SSLContext sslContext = SSLContext.getInstance(configuration.getSslProtocol());
            sslContext.init(
                    keyManagerFactory.getKeyManagers(), trustManagerFactory.getTrustManagers(), new SecureRandom());

            return sslContext;
        } catch (KeyStoreException | NoSuchAlgorithmException | UnrecoverableKeyException | KeyManagementException e) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException("Unable to create SSL context", e);
        }
    }
}
