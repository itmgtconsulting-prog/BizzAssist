package dk.tinglysning.xmlapi.reference.client;

import dk.tinglysning.xmlapi.reference.client.configurations.ApiClientConfiguration;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.time.Duration;
import lombok.RequiredArgsConstructor;

/**
 * Wrapper for a HTTP client that sends POST and GET requests to the e-Tinglysning API using a configured {@link HttpClient}
 * and {@link ApiClientConfiguration}.
 * <p>
 * Provides utility methods for building and sending HTTP requests with proper headers and SSL authentication required by the e-Tinglysning API.
 * </p>
 */
@RequiredArgsConstructor
public class XmlApiHttpClient {
    private final HttpClient httpClient;
    private final ApiClientConfiguration configuration;

    /**
     * Sends a blocking HTTP POST request to the specified endpoint with the provided XML payload and headers.
     * This method is intended for submitting data to the Tinglysning API (anmeldelser).
     * If this method is going to be used in a real implementation, an appropriate handling strategy should be considered.
     *
     * @param endpoint     the endpoint path to append to the base URL
     * @param xmlPayload   the XML payload to send in the request body
     * @param headerValues the headers to include in the request, wrapped in {@link HeaderValues}
     * @param bodyHandler  the response body handler of class {@link HttpResponse.BodyHandler}
     * @param <T>          the type of the response body
     * @return a {@link HttpResponse} containing the response
     * @throws HttpTimeoutException if a response is not received from the server within the time specified in {@link ApiClientConfiguration}
     * @throws IOException if there is an issue serializing the request or response, or when file descriptor exhaustion occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public <T> HttpResponse<T> sendPostRequest(
            String endpoint, String xmlPayload, HeaderValues headerValues, HttpResponse.BodyHandler<T> bodyHandler)
            throws IOException, InterruptedException {
        if (endpoint == null || xmlPayload == null || headerValues == null || bodyHandler == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException("All values must be provided");
        }

        URI fullUrl = URI.create(configuration.getBaseUrl() + endpoint);

        HttpRequest request = getHttpRequestBuilderWithHeaders(HttpRequest.newBuilder(), headerValues)
                .uri(fullUrl)
                .timeout(Duration.ofSeconds(configuration.getRequestTimeoutSeconds()))
                .POST(HttpRequest.BodyPublishers.ofString(xmlPayload))
                .build();

        return httpClient.send(request, bodyHandler);
    }

    /**
     * Sends a blocking HTTP GET request to the specified endpoint with the provided headers.
     * This method could be used to request a subscription identifier from the Tinglysning API (Abonnement)
     * If this method is going to be used in a real implementation, an appropriate handling strategy should be considered.
     *
     * @param endpoint     the endpoint path to append to the base URL
     * @param headerValues the headers to include in the request, wrapped in {@link HeaderValues}
     * @param xmlPayload   the XML payload to send in the request body
     * @param bodyHandler  the response body handler of class {@link HttpResponse.BodyHandler}
     * @param <T>          the type of the response body
     * @return a {@link HttpResponse} containing the response
     * @throws HttpTimeoutException if a response is not received from the server within the time specified in {@link ApiClientConfiguration}
     * @throws IOException if there is an issue serializing the request or response, or when file descriptor exhaustion occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public <T> HttpResponse<T> sendGetRequest(
            String endpoint, String xmlPayload, HeaderValues headerValues, HttpResponse.BodyHandler<T> bodyHandler)
            throws IOException, InterruptedException {
        if (endpoint == null || xmlPayload == null || headerValues == null || bodyHandler == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException("All values must be provided");
        }

        URI fullUrl = URI.create(configuration.getBaseUrl() + endpoint);

        HttpRequest request = getHttpRequestBuilderWithHeaders(HttpRequest.newBuilder(), headerValues)
                .uri(fullUrl)
                .method("GET", HttpRequest.BodyPublishers.ofString(xmlPayload))
                .timeout(Duration.ofSeconds(configuration.getRequestTimeoutSeconds()))
                .build();

        return httpClient.send(request, bodyHandler);
    }

    /**
     * Adds headers from a {@link HeaderValues} instance to the given {@link HttpRequest.Builder}.
     *
     * @param builder the {@code HttpRequest.Builder} to add headers to
     * @param headers the {@code HeaderValues} containing headers to add
     * @return the updated {@code HttpRequest.Builder} with the specified headers
     */
    public static HttpRequest.Builder getHttpRequestBuilderWithHeaders(
            HttpRequest.Builder builder, HeaderValues headers) {
        headers.getHeaders().forEach(builder::header);
        return builder;
    }
}
