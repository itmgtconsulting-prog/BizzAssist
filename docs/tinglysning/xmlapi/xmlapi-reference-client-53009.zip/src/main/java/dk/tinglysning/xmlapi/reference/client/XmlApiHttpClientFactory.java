package dk.tinglysning.xmlapi.reference.client;

import dk.tinglysning.xmlapi.reference.client.configurations.ApiClientConfiguration;
import java.net.http.HttpClient;
import java.time.Duration;
import javax.net.ssl.SSLContext;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

/**
 * Factory class for creating instances of {@link XmlApiHttpClient} configured with a custom
 * {@link ApiClientConfiguration}.
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class XmlApiHttpClientFactory {

    /**
     * Creates a new {@link XmlApiHttpClient} instance using the provided {@link ApiClientConfiguration}.
     *
     * <p>The method sets up an {@link HttpClient} with a custom {@link SSLContext} and connect timeout,
     * based on the configuration settings.
     *
     * @param configuration the API client configuration, including keystore/truststore settings, SSL protocol,
     *      and HTTP timeouts.
     * @return a new {@link XmlApiHttpClient} instance configured accordingly
     * @throws IllegalStateException if the SSL context cannot be created or the configuration is invalid
     */
    public static XmlApiHttpClient create(ApiClientConfiguration configuration) {
        SSLContext sslContext = SslContextFactory.createSslContext(configuration);

        HttpClient client = HttpClient.newBuilder()
                .sslContext(sslContext)
                .connectTimeout(Duration.ofSeconds(configuration.getConnectTimeoutSeconds()))
                .build();

        return new XmlApiHttpClient(client, configuration);
    }
}
