package dk.tinglysning.xmlapi.reference.client.configurations;

import static dk.tinglysning.xmlapi.reference.client.configurations.KeyStoreUtil.loadKeyStore;

import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.Objects;
import java.util.Properties;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;

/**
 * Contains all required properties needed to create a client connecting to the e-Tinglysning API.
 * <p>
 * This class groups all relevant properties loaded from the {@code application.properties} file and keystore files
 * loaded
 * from resources. Configuration properties include paths, passwords, and types for both keystore and truststore, as
 * well as API connection settings such as the base URL, SSL protocol, and timeout values.
 * </p>
 *
 * <p>
 * Instances of this class are typically created using the builder pattern.
 * </p>
 */
@Getter
@Builder(access = AccessLevel.PUBLIC, toBuilder = true)
public class ApiClientConfiguration {
    private final String systemKeystorePath;
    private final String systemKeystorePassword;
    private final String systemKeystorekeyAlias;
    private final KeystoreType systemKeystoreType;

    private final String truststorePath;
    private final String truststorePassword;
    private final KeystoreType truststoreType;

    private final String companyKeystorePath;
    private final String companyKeystorePassword;
    private final String companyKeystorekeyAlias;
    private final KeystoreType companyKeystoreType;

    private final KeyStore systemKeyStore;
    private final KeyStore trustStore;
    private final KeyStore companyKeyStore;

    private final PrivateKey signPrivateKey;
    private final X509Certificate signCertificate;

    private final PrivateKey signPrivateKeyNonRepudiation;
    private final X509Certificate signCertificateNonRepudiation;

    private final String baseUrl;
    private final String sslProtocol;
    private final int connectTimeoutSeconds;
    private final int requestTimeoutSeconds;

    private final Properties properties;

    /**
     * Loads and constructs an {@link ApiClientConfiguration} instance using the provided {@link Properties}.
     * <p>
     * This method performs the following:
     * <ul>
     *   <li>Loads the system keystore, truststore, and company keystore from the specified file paths.</li>
     *   <li>Extracts signing keys and certificates (both standard and non-repudiation) from the loaded keystores using the defined aliases and passwords.</li>
     *   <li>Populates an {@link ApiClientConfiguration} builder with all required SSL and API client properties.</li>
     *   <li>Populates additional API configuration options such as base URL, SSL protocol, and timeouts.</li>
     * </ul>
     *
     * <p>
     * Expected property keys include:
     * <ul>
     *   <li>ssl.keystore.system.certificate.path</li>
     *   <li>ssl.keystore.system.certificate.password</li>
     *   <li>ssl.keystore.system.certificate.key.alias</li>
     *   <li>ssl.keystore.system.certificate.type</li>
     *   <li>ssl.truststore.path</li>
     *   <li>ssl.truststore.password</li>
     *   <li>ssl.truststore.type</li>
     *   <li>ssl.keystore.company.certificate.path</li>
     *   <li>ssl.keystore.company.certificate.password</li>
     *   <li>ssl.keystore.company.certificate.key.alias</li>
     *   <li>ssl.keystore.company.certificate.type</li>
     *   <li>api.base-url</li>
     *   <li>ssl.protocol.type</li>
     *   <li>http.client.connect-timeout-seconds</li>
     *   <li>http.client.request-timeout-seconds</li>
     * </ul>
     *
     * @param properties a {@link Properties} object containing all required configuration keys for keystores, truststores,
     *                   and API client initialization. Expected keys follows application properties naming and include:
     * @return an {@code ApiClientConfiguration} instance populated with all required information to initialize the API client,
     *         including loaded keystores, truststore, signing keys/certificates, and API properties.
     * @throws IllegalStateException if keystores, truststore, or required keys/certificates cannot be loaded due to missing files,
     *                               incorrect passwords, invalid aliases, or other initialization errors.
     */
    public static ApiClientConfiguration getApiConfigWithProperties(Properties properties) {
        String systemKeyStorePath = properties.getProperty("ssl.keystore.system.certificate.path");
        String systemKeyStorePassword = properties.getProperty("ssl.keystore.system.certificate.password");
        String systemKeyStoreAlias = properties.getProperty("ssl.keystore.system.certificate.key.alias");
        KeystoreType systemKeyStoreType = KeystoreType.valueOf(
                getNamedProp(properties, "ssl.keystore.system.certificate.type", KeystoreType.PKCS12.getType()));

        String trustStorePath = properties.getProperty("ssl.truststore.path");
        String trustStorePassword = properties.getProperty("ssl.truststore.password");
        KeystoreType trustStoreType =
                KeystoreType.valueOf(getNamedProp(properties, "ssl.truststore.type", KeystoreType.PKCS12.getType()));

        String companyKeystorePath = properties.getProperty("ssl.keystore.company.certificate.path");
        String companyKeystorePassword = properties.getProperty("ssl.keystore.company.certificate.password");
        String companyKeystoreAlias = properties.getProperty("ssl.keystore.company.certificate.key.alias");
        KeystoreType companyKeystoreType = KeystoreType.valueOf(
                getNamedProp(properties, "ssl.keystore.company.certificate.type", KeystoreType.PKCS12.getType()));

        KeyStore systemKeyStore = loadKeyStore(systemKeyStorePath, systemKeyStorePassword, systemKeyStoreType);
        KeyStore trustStore = loadKeyStore(trustStorePath, trustStorePassword, trustStoreType);
        KeyStore companyKeyStore = loadKeyStore(companyKeystorePath, companyKeystorePassword, companyKeystoreType);

        PrivateKey signingKey;
        X509Certificate signingCertificate;
        PrivateKey signingKeyNonRepudiation;
        X509Certificate signingCertificateNonRepudiation;
        try {
            signingKey = (PrivateKey) systemKeyStore.getKey(systemKeyStoreAlias, systemKeyStorePassword.toCharArray());
            signingCertificate = (X509Certificate) systemKeyStore.getCertificate(systemKeyStoreAlias);

            signingKeyNonRepudiation =
                    (PrivateKey) companyKeyStore.getKey(companyKeystoreAlias, companyKeystorePassword.toCharArray());
            signingCertificateNonRepudiation = (X509Certificate) companyKeyStore.getCertificate(companyKeystoreAlias);
        } catch (Exception e) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            String message = "Could not create signing pairs. Verify that keystores are loaded and aliases are correct";
            throw new IllegalStateException(message, e);
        }

        return ApiClientConfiguration.builder()
                .systemKeystorePath(systemKeyStorePath)
                .systemKeystorePassword(systemKeyStorePassword)
                .systemKeystorekeyAlias(systemKeyStoreAlias)
                .systemKeystoreType(systemKeyStoreType)
                .truststorePath(trustStorePath)
                .truststorePassword(trustStorePassword)
                .truststoreType(trustStoreType)
                .companyKeystorePath(companyKeystorePath)
                .companyKeystorePassword(companyKeystorePassword)
                .companyKeystorekeyAlias(companyKeystoreAlias)
                .companyKeystoreType(companyKeystoreType)
                .systemKeyStore(systemKeyStore)
                .trustStore(trustStore)
                .companyKeyStore(companyKeyStore)
                .signPrivateKey(signingKey)
                .signCertificate(signingCertificate)
                .signPrivateKeyNonRepudiation(signingKeyNonRepudiation)
                .signCertificateNonRepudiation(signingCertificateNonRepudiation)
                .baseUrl(properties.getProperty("api.base-url"))
                .sslProtocol(properties.getProperty("ssl.protocol.type"))
                .connectTimeoutSeconds(getIntNamedProp(properties, "http.client.connect-timeout-seconds", 2))
                .requestTimeoutSeconds(getIntNamedProp(properties, "http.client.request-timeout-seconds", 6))
                .properties(properties)
                .build();
    }

    /**
     * Loads and constructs an {@link ApiClientConfiguration} instance using {@code application.properties} file
     * located on the application's classpath.
     * <p>
     * This method loads properties from the classpath using {@link #loadProperties() }, then delegates to
     * {@link #getApiConfigWithProperties(Properties)} to construct the configuration object.
     *
     * @return an {@code ApiClientConfiguration} instance populated with all required information to initialize the API client,
     *         including loaded keystores, truststore, signing keys/certificates, and API properties.
     * @throws IllegalStateException if keystores, truststore, or required keys/certificates cannot be loaded due to missing files,
     *                               incorrect passwords, invalid aliases, or other initialization errors.
     */
    public static ApiClientConfiguration getApiConfigWithAppProperties() {
        Properties props = loadProperties();
        return getApiConfigWithProperties(props);
    }

    /**
     * Loads application configuration properties from the {@code application.properties} file
     * located on the application's classpath.
     * <p>
     * This method attempts to read the {@code application.properties} file.
     * If the file is found, it loads its contents into a {@link Properties} object and returns it.
     * </p>
     * <p>
     * <strong>Note:</strong> If the properties file is missing or cannot be loaded, this method throws
     * an {@link IllegalStateException}.
     * </p>
     *
     * @return a {@link Properties} object containing all key-value pairs loaded from {@code application.properties}
     * @throws IllegalStateException if the {@code application.properties} file cannot be found,
     *                               or if an I/O error occurs during loading
     */
    private static Properties loadProperties() {
        try (InputStream inputStream =
                Thread.currentThread().getContextClassLoader().getResourceAsStream("application.properties")) {
            Objects.requireNonNull(inputStream);
            Properties properties = new Properties();
            properties.load(inputStream);
            return properties;
        } catch (IOException e) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException("Error loading properties. Is the properties file missing?", e);
        }
    }

    /**
     * Retrieves the property value associated with the specified key, returning a default value if the key does not exist.
     *
     * @param key          the property key
     * @param defaultValue the default value to return if the key is not found
     * @return the property value, or {@code defaultValue} if the key does not exist
     */
    private static String getNamedProp(Properties properties, String key, String defaultValue) {
        String value = properties.getProperty(key);
        return value != null && !value.isEmpty() ? value : defaultValue;
    }

    /**
     * Retrieves the property value as an integer associated with the specified key, returning a default value if the key
     * does not exist or if the value cannot be parsed as an integer.
     *
     * @param key          the property key
     * @param defaultValue the default value to return if the key is not found or parsing fails
     * @return the property value as an integer, or {@code defaultValue} if the key does not exist or cannot be parsed
     */
    private static int getIntNamedProp(Properties properties, String key, int defaultValue) {
        String value = properties.getProperty(key);
        try {
            return value != null ? Integer.parseInt(value) : defaultValue;
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }
}
