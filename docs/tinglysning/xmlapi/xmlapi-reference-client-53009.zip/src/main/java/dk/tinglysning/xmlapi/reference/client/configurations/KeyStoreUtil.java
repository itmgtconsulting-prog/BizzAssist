package dk.tinglysning.xmlapi.reference.client.configurations;

import dk.tinglysning.xmlapi.reference.client.SslContextFactory;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

/**
 * {@link KeyStore} utility methods.
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class KeyStoreUtil {

    /**
     * Loads a {@link KeyStore} from the specified resource path using the given password and keystore type.
     *
     * @param path     the resource path to the keystore file
     * @param password the password for the keystore, or {@code null} if not required
     * @param type     the {@link KeystoreType} specifying the keystore version/type
     * @return the loaded {@link KeyStore} instance
     * @throws IllegalStateException if the keystore cannot be loaded due to a missing resource,
     *                               I/O error, certificate error, or other issues
     */
    public static KeyStore loadKeyStore(String path, String password, KeystoreType type) {
        try (InputStream is = SslContextFactory.class.getClassLoader().getResourceAsStream(path)) {
            if (is == null) {
                // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
                // Replace with appropriate error handling as needed.
                throw new IllegalStateException(String.format("Resource not found: %s", path));
            }

            KeyStore keyStore = KeyStore.getInstance(type.getType());
            char[] keystorePassword = password != null ? password.toCharArray() : null;
            keyStore.load(is, keystorePassword);

            return keyStore;
        } catch (IOException
                | CertificateException
                | KeyStoreException
                | NoSuchAlgorithmException
                | NullPointerException exception) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            String message = String.format("Could not open key store %s.", path);
            throw new IllegalStateException(message, exception);
        }
    }
}
