package dk.tinglysning.xmlapi.reference.client.configurations;

import lombok.Getter;

/**
 * Enumeration representing keystores types for SSL configuration that are used in reference client.
 */
@Getter
public enum KeystoreType {
    JKS("JKS"),
    PKCS12("PKCS12");

    private final String type;

    KeystoreType(String type) {
        this.type = type;
    }
}
