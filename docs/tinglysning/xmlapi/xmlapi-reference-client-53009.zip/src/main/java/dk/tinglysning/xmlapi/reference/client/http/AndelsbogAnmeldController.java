package dk.tinglysning.xmlapi.reference.client.http;

import dk.tinglysning.xmlapi.reference.client.HeaderValues;
import dk.tinglysning.xmlapi.reference.client.XmlApiHttpClient;
import dk.tinglysning.xmlapi.reference.client.configurations.ApiClientConfiguration;
import java.io.IOException;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.util.UUID;
import lombok.RequiredArgsConstructor;

/**
 * HTTP client for sending "AndelsbogAnmeld" requests to the e-Tinglysning API endpoint.
 * <p>
 * Provides a method for posting XML payloads using {@link XmlApiHttpClient}
 * with message ID and relates-to headers to the {@code /AndelsbogAnmeld/} endpoint.
 * If using this class as inspiration for a production-ready implementation, a robust error handling strategy that aligns with your organisation's requirements must be considered.
 * </p>
 */
@RequiredArgsConstructor
public class AndelsbogAnmeldController {

    private static final String MISSING_REQUIRED_PARAMETERS_ERROR = "XmlPayload and messageId must be provided";
    private final XmlApiHttpClient xmlApiHttpClient;

    /**
     * Sends a blocking POST request to the {@code /AndelsbogAnmeld/AfgiftPantebrevPaategn} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postAfgiftPantebrevPaategn(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/AndelsbogAnmeld/AfgiftPantebrevPaategn",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /AndelsbogAnmeld/ArrestAndelOpret} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postArrestAndelOpret(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/AndelsbogAnmeld/ArrestAndelOpret",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /AndelsbogAnmeld/DigitaliserPantebrevAndelPaategn} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postDigitaliserPantebrevAndelPaategn(
            String xmlPayload, String messageId, String relatesTo) throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/AndelsbogAnmeld/DigitaliserPantebrevAndelPaategn",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /AndelsbogAnmeld/DokumentAfgiftPaategn} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postDokumentAfgiftPaategn(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/AndelsbogAnmeld/DokumentAfgiftPaategn",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /AndelsbogAnmeld/OmdannelseTilAfgiftsPantebrevPaategn} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postOmdannelseTilAfgiftsPantebrevPaategn(
            String xmlPayload, String messageId, String relatesTo) throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/AndelsbogAnmeld/OmdannelseTilAfgiftsPantebrevPaategn",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /AndelsbogAnmeld/DokumentPaategn} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postDokumentPaategn(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/AndelsbogAnmeld/DokumentPaategn",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /AndelsbogAnmeld/DokumentSamlingAflys} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postDokumentSamlingAflys(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/AndelsbogAnmeld/DokumentSamlingAflys",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /AndelsbogAnmeld/DokumentRettighedSamlingRelakser} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postDokumentRettighedSamlingRelakser(
            String xmlPayload, String messageId, String relatesTo) throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/AndelsbogAnmeld/DokumentRettighedSamlingRelakser",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /AndelsbogAnmeld/EjerpantebrevAndelOpret} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postEjerpantebrevAndelOpret(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/AndelsbogAnmeld/EjerpantebrevAndelOpret",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /AndelsbogAnmeld/FuldmagtAndelOpret} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postFuldmagtAndelOpret(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/AndelsbogAnmeld/FuldmagtAndelOpret",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /AndelsbogAnmeld/FuldmagtAndelTilbagekald} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postFuldmagtAndelTilbagekald(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/AndelsbogAnmeld/FuldmagtAndelTilbagekald",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /AndelsbogAnmeld/HaeftelseKombinationAndelPaategn} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postHaeftelseKombinationAndelPaategn(
            String xmlPayload, String messageId, String relatesTo) throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/AndelsbogAnmeld/HaeftelseKombinationAndelPaategn",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /AndelsbogAnmeld/MeddelelseOffentligAndelOpret} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postMeddelelseOffentligAndelOpret(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/AndelsbogAnmeld/MeddelelseOffentligAndelOpret",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /AndelsbogAnmeld/MeddelelseOffentligPaategn} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postMeddelelseOffentligPaategn(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/AndelsbogAnmeld/MeddelelseOffentligPaategn",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /AndelsbogAnmeld/PantebrevAndelOpret} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postPantebrevAndelOpret(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/AndelsbogAnmeld/PantebrevAndelOpret",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /AndelsbogAnmeld/SkadesloesbrevAndelOpret} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postSkadesloesbrevAndelOpret(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/AndelsbogAnmeld/SkadesloesbrevAndelOpret",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /AndelsbogAnmeld/UdlaegAndelOpret} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postUdlaegAndelOpret(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/AndelsbogAnmeld/UdlaegAndelOpret",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /AndelsbogAnmeld/UnderpantsaetningAndelOpret} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postUnderpantsaetningAndelOpret(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/AndelsbogAnmeld/UnderpantsaetningAndelOpret",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /AndelsbogAnmeld/UnderpantsaetningAndelPaategn} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postUnderpantsaetningAndelPaategn(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/AndelsbogAnmeld/UnderpantsaetningAndelPaategn",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /AndelsbogAnmeld/DokumentAdkomstErklaering} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postDokumentAdkomstErklaering(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/AndelsbogAnmeld/DokumentAdkomstErklaering",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }
}
