package dk.tinglysning.xmlapi.reference.client.http;

import dk.tinglysning.xmlapi.reference.client.HeaderValues;
import dk.tinglysning.xmlapi.reference.client.XmlApiHttpClient;
import dk.tinglysning.xmlapi.reference.client.configurations.ApiClientConfiguration;
import java.io.IOException;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.util.UUID;
import lombok.RequiredArgsConstructor;

/**
 * HTTP client for sending "AnmeldelseSvar" requests to the e-Tinglysning API endpoint.
 * <p>
 * Provides a method for posting XML payloads using {@link XmlApiHttpClient}
 * with message ID and relates-to headers to the {@code /AnmeldelseSvar/} endpoint.
 * If using this class as inspiration for a production-ready implementation, a robust error handling strategy that aligns with your organisation's requirements must be considered.
 * </p>
 */
@RequiredArgsConstructor
public class AnmeldelseSvarController {

    private static final String MISSING_REQUIRED_PARAMETERS_ERROR = "XmlPayload and messageId must be provided";
    private final XmlApiHttpClient xmlApiHttpClient;

    /**
     * Sends a blocking POST request to the {@code /AnmeldelseSvar/AnmeldelseSvarHent} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postAnmeldelseSvarHent(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/AnmeldelseSvar/AnmeldelseSvarHent",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }
}
