package dk.tinglysning.xmlapi.reference.client.http;

import dk.tinglysning.xmlapi.reference.client.HeaderValues;
import dk.tinglysning.xmlapi.reference.client.XmlApiHttpClient;
import dk.tinglysning.xmlapi.reference.client.configurations.ApiClientConfiguration;
import java.io.IOException;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.util.UUID;
import lombok.RequiredArgsConstructor;

/**
 * HTTP client for sending "BilbogAnmeld" requests to the e-Tinglysning API endpoint.
 * <p>
 * Provides a method for posting XML payloads using {@link XmlApiHttpClient}
 * with message ID and relates-to headers to the {@code /BilbogAnmeld/} endpoint.
 * If using this class as inspiration for a production-ready implementation, a robust error handling strategy that aligns with your organisation's requirements must be considered.
 * </p>
 */
@RequiredArgsConstructor
public class BilbogAnmeldController {

    private static final String MISSING_REQUIRED_PARAMETERS_ERROR = "XmlPayload and messageId must be provided";
    private final XmlApiHttpClient xmlApiHttpClient;

    /**
     * Sends a blocking POST request to the {@code /BilbogAnmeld/ArrestBilOpret} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postArrestBilOpret(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/BilbogAnmeld/ArrestBilOpret", xmlPayload, customHeaderValue, HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /BilbogAnmeld/DigitaliserPantebrevBilPaategn} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postDigitaliserPantebrevBilPaategn(
            String xmlPayload, String messageId, String relatesTo) throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/BilbogAnmeld/DigitaliserPantebrevBilPaategn",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /BilbogAnmeld/DokumentAfgiftPaategn} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postDokumentAfgiftPaategn(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/BilbogAnmeld/DokumentAfgiftPaategn",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /BilbogAnmeld/DokumentPaategn} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postDokumentPaategn(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/BilbogAnmeld/DokumentPaategn", xmlPayload, customHeaderValue, HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /BilbogAnmeld/DokumentSamlingAflys} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postDokumentSamlingAflys(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/BilbogAnmeld/DokumentSamlingAflys",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /BilbogAnmeld/DokumentRettighedSamlingRelakser} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postDokumentRettighedSamlingRelakser(
            String xmlPayload, String messageId, String relatesTo) throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/BilbogAnmeld/DokumentRettighedSamlingRelakser",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /BilbogAnmeld/EjendomsforbeholdBilOpret} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postEjendomsforbeholdBilOpret(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/BilbogAnmeld/EjendomsforbeholdBilOpret",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /BilbogAnmeld/EjerpantebrevBilOpret} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postEjerpantebrevBilOpret(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/BilbogAnmeld/EjerpantebrevBilOpret",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /BilbogAnmeld/FuldmagtBilOpret} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postFuldmagtBilOpret(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/BilbogAnmeld/FuldmagtBilOpret", xmlPayload, customHeaderValue, HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /BilbogAnmeld/FuldmagtBilTilbagekald} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postFuldmagtBilTilbagekald(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/BilbogAnmeld/FuldmagtBilTilbagekald",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /BilbogAnmeld/HaeftelseKombinationBilPaategn} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postHaeftelseKombinationBilPaategn(
            String xmlPayload, String messageId, String relatesTo) throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/BilbogAnmeld/HaeftelseKombinationBilPaategn",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /BilbogAnmeld/MeddelelseOffentligBilOpret} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postMeddelelseOffentligBilOpret(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/BilbogAnmeld/MeddelelseOffentligBilOpret",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /BilbogAnmeld/MeddelelseOffentligPaategn} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postMeddelelseOffentligPaategn(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/BilbogAnmeld/MeddelelseOffentligPaategn",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /BilbogAnmeld/PantebrevBilOpret} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postPantebrevBilOpret(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/BilbogAnmeld/PantebrevBilOpret", xmlPayload, customHeaderValue, HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /BilbogAnmeld/SkadesloesbrevBilOpret} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postSkadesloesbrevBilOpret(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/BilbogAnmeld/SkadesloesbrevBilOpret",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /BilbogAnmeld/UdlaegBilOpret} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postUdlaegBilOpret(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/BilbogAnmeld/UdlaegBilOpret", xmlPayload, customHeaderValue, HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /BilbogAnmeld/UnderpantsaetningBilOpret} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postUnderpantsaetningBilOpret(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/BilbogAnmeld/UnderpantsaetningBilOpret",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /BilbogAnmeld/UnderpantsaetningBilPaategn} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postUnderpantsaetningBilPaategn(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/BilbogAnmeld/UnderpantsaetningBilPaategn",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }
}
