package dk.tinglysning.xmlapi.reference.client.http;

import dk.tinglysning.xmlapi.reference.client.HeaderValues;
import dk.tinglysning.xmlapi.reference.client.XmlApiHttpClient;
import dk.tinglysning.xmlapi.reference.client.configurations.ApiClientConfiguration;
import java.io.IOException;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.util.UUID;
import lombok.RequiredArgsConstructor;

/**
 * HTTP client for sending "ElektroniskAkt" requests to the e-Tinglysning API endpoint.
 * <p>
 * Provides a method for posting XML payloads using {@link XmlApiHttpClient}
 * with message ID and relates-to headers to the {@code /ElektroniskAkt/} endpoint.
 * If using this class as inspiration for a production-ready implementation, a robust error handling strategy that aligns with your organisation's requirements must be considered.
 * </p>
 */
@RequiredArgsConstructor
public class ElektroniskAktController {

    private static final String MISSING_REQUIRED_PARAMETERS_ERROR = "XmlPayload and messageId must be provided";
    private final XmlApiHttpClient xmlApiHttpClient;

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/SenesteAendringTinglysningsobjektHent} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postSenesteAendringTinglysningsobjektHent(
            String xmlPayload, String messageId, String relatesTo) throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/SenesteAendringTinglysningsobjektHent",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/AendredeTinglysningsobjekterHent} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postAendredeTinglysningsobjekterHent(
            String xmlPayload, String messageId, String relatesTo) throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/AendredeTinglysningsobjekterHent",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/AliasSoeg} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postAliasSoeg(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/AliasSoeg", xmlPayload, customHeaderValue, HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/AndelsbogDokumentAktuelHent} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postAndelsbogDokumentAktuelHent(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/AndelsbogDokumentAktuelHent",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/AndelsbogDokumentRevisionssporHent} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postAndelsbogDokumentRevisionssporHent(
            String xmlPayload, String messageId, String relatesTo) throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/AndelsbogDokumentRevisionssporHent",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/AndelSoeg} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postAndelSoeg(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/AndelSoeg", xmlPayload, customHeaderValue, HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/AndelSummariskHent} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postAndelSummariskHent(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/AndelSummariskHent",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/BilbogDokumentAktuelHent} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postBilbogDokumentAktuelHent(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/BilbogDokumentAktuelHent",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/BilbogDokumentRevisionssporHent} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postBilbogDokumentRevisionssporHent(
            String xmlPayload, String messageId, String relatesTo) throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/BilbogDokumentRevisionssporHent",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/BilSoeg} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postBilSoeg(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/BilSoeg", xmlPayload, customHeaderValue, HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/BilSummariskHent} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postBilSummariskHent(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/BilSummariskHent",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/DokumentAktuelHent} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postDokumentAktuelHent(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/DokumentAktuelHent",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/DokumentTinglysningsobjekterHent} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postDokumentTinglysningsobjekterHent(
            String xmlPayload, String messageId, String relatesTo) throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/DokumentTinglysningsobjekterHent",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/DokumentRevisionssporHent} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postDokumentRevisionssporHent(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/DokumentRevisionssporHent",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/EjendomAdkomsterHent} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postEjendomAdkomsterHent(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/EjendomAdkomsterHent",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/EjendomHistoriskAdkomsterHent} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postEjendomHistoriskAdkomsterHent(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/EjendomHistoriskAdkomsterHent",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/EjendomHaeftelserHent} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postEjendomHaeftelserHent(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/EjendomHaeftelserHent",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/EjendomIndskannetAktHent} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postEjendomIndskannetAktHent(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/EjendomIndskannetAktHent",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/EjendomServitutterHent} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postEjendomServitutterHent(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/EjendomServitutterHent",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/EjendomSoeg} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postEjendomSoeg(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/EjendomSoeg", xmlPayload, customHeaderValue, HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/EjendomStamoplysningerHent} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postEjendomStamoplysningerHent(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/EjendomStamoplysningerHent",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/EjendomSummariskHent} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postEjendomSummariskHent(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/EjendomSummariskHent",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/EjendomUdskriftBestil} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postEjendomUdskriftBestil(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/EjendomUdskriftBestil",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/FuldmagtAndelSoeg} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postFuldmagtAndelSoeg(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/FuldmagtAndelSoeg",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/FuldmagtBilSoeg} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postFuldmagtBilSoeg(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/FuldmagtBilSoeg", xmlPayload, customHeaderValue, HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/FuldmagtFastEjendomSoeg} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postFuldmagtFastEjendomSoeg(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/FuldmagtFastEjendomSoeg",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/FuldmagtLoesoereSoeg} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postFuldmagtLoesoereSoeg(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/FuldmagtLoesoereSoeg",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/LoesoereSoeg} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postLoesoereSoeg(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/LoesoereSoeg", xmlPayload, customHeaderValue, HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/LoesoereSummariskHent} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postLoesoereSummariskHent(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/LoesoereSummariskHent",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/PersonbogDokumentAktuelHent} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postPersonbogDokumentAktuelHent(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/PersonbogDokumentAktuelHent",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/PersonbogDokumentRevisionssporHent} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postPersonbogDokumentRevisionssporHent(
            String xmlPayload, String messageId, String relatesTo) throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/PersonbogDokumentRevisionssporHent",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/PersondokumentSummariskHent} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postPersondokumentSummariskHent(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/PersondokumentSummariskHent",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/PersondokumentSkifteretHent} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postPersondokumentSkifteretHent(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/PersondokumentSkifteretHent",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/UdskriftBestil} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postUdskriftBestil(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/UdskriftBestil", xmlPayload, customHeaderValue, HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /ElektroniskAkt/VirksomhedSoeg} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postVirksomhedSoeg(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/ElektroniskAkt/VirksomhedSoeg", xmlPayload, customHeaderValue, HttpResponse.BodyHandlers.ofString());
    }
}
