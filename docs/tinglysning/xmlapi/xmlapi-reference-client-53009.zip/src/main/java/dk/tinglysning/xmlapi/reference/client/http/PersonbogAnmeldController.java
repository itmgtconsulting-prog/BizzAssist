package dk.tinglysning.xmlapi.reference.client.http;

import dk.tinglysning.xmlapi.reference.client.HeaderValues;
import dk.tinglysning.xmlapi.reference.client.XmlApiHttpClient;
import dk.tinglysning.xmlapi.reference.client.configurations.ApiClientConfiguration;
import java.io.IOException;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.util.UUID;
import lombok.RequiredArgsConstructor;

/**
 * HTTP client for sending "PersonbogAnmeld" requests to the e-Tinglysning API endpoint.
 * <p>
 * Provides a method for posting XML payloads using {@link XmlApiHttpClient}
 * with message ID and relates-to headers to the {@code /PersonbogAnmeld/} endpoint.
 * If using this class as inspiration for a production-ready implementation, a robust error handling strategy that aligns with your organisation's requirements must be considered.
 * </p>
 */
@RequiredArgsConstructor
public class PersonbogAnmeldController {

    private static final String MISSING_REQUIRED_PARAMETERS_ERROR = "XmlPayload and messageId must be provided";
    private final XmlApiHttpClient xmlApiHttpClient;

    /**
     * Sends a blocking POST request to the {@code /PersonbogAnmeld/DigitaliserPantebrevLoesoerePaategn} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postDigitaliserPantebrevLoesoerePaategn(
            String xmlPayload, String messageId, String relatesTo) throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/PersonbogAnmeld/DigitaliserPantebrevLoesoerePaategn",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /PersonbogAnmeld/DokumentAfgiftPaategn} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postDokumentAfgiftPaategn(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/PersonbogAnmeld/DokumentAfgiftPaategn",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /PersonbogAnmeld/DokumentPaategn} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postDokumentPaategn(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/PersonbogAnmeld/DokumentPaategn",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /PersonbogAnmeld/DokumentSamlingAflys} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postDokumentSamlingAflys(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/PersonbogAnmeld/DokumentSamlingAflys",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /PersonbogAnmeld/DokumentRettighedSamlingRelakser} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postDokumentRettighedSamlingRelakser(
            String xmlPayload, String messageId, String relatesTo) throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/PersonbogAnmeld/DokumentRettighedSamlingRelakser",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /PersonbogAnmeld/EjerpantebrevLoesoereOpret} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postEjerpantebrevLoesoereOpret(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/PersonbogAnmeld/EjerpantebrevLoesoereOpret",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /PersonbogAnmeld/EjerpantebrevVirksomhedspantOpret} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postEjerpantebrevVirksomhedspantOpret(
            String xmlPayload, String messageId, String relatesTo) throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/PersonbogAnmeld/EjerpantebrevVirksomhedspantOpret",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /PersonbogAnmeld/FuldmagtLoesoereOpret} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postFuldmagtLoesoereOpret(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/PersonbogAnmeld/FuldmagtLoesoereOpret",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /PersonbogAnmeld/FuldmagtLoesoereTilbagekald} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postFuldmagtLoesoereTilbagekald(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/PersonbogAnmeld/FuldmagtLoesoereTilbagekald",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /PersonbogAnmeld/HaeftelseKombinationLoesoerePaategn} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postHaeftelseKombinationLoesoerePaategn(
            String xmlPayload, String messageId, String relatesTo) throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/PersonbogAnmeld/HaeftelseKombinationLoesoerePaategn",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /PersonbogAnmeld/HoestpantebrevOpret} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postHoestpantebrevOpret(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/PersonbogAnmeld/HoestpantebrevOpret",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /PersonbogAnmeld/MeddelelseOffentligPaategn} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postMeddelelseOffentligPaategn(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/PersonbogAnmeld/MeddelelseOffentligPaategn",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /PersonbogAnmeld/PantebrevLoesoereOpret} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postPantebrevLoesoereOpret(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/PersonbogAnmeld/PantebrevLoesoereOpret",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /PersonbogAnmeld/PantsaetningsforbudLoesoereOpret} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postPantsaetningsforbudLoesoereOpret(
            String xmlPayload, String messageId, String relatesTo) throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/PersonbogAnmeld/PantsaetningsforbudLoesoereOpret",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /PersonbogAnmeld/SkadesloesbrevLoesoereOpret} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postSkadesloesbrevLoesoereOpret(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/PersonbogAnmeld/SkadesloesbrevLoesoereOpret",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /PersonbogAnmeld/TinglysningFormueforholdOpret} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postTinglysningFormueforholdOpret(String xmlPayload, String messageId, String relatesTo)
            throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/PersonbogAnmeld/TinglysningFormueforholdOpret",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /PersonbogAnmeld/TinglysningFormueforholdPaategn} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postTinglysningFormueforholdPaategn(
            String xmlPayload, String messageId, String relatesTo) throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/PersonbogAnmeld/TinglysningFormueforholdPaategn",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /PersonbogAnmeld/UnderpantsaetningLoesoereOpret} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postUnderpantsaetningLoesoereOpret(
            String xmlPayload, String messageId, String relatesTo) throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/PersonbogAnmeld/UnderpantsaetningLoesoereOpret",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Sends a blocking POST request to the {@code /PersonbogAnmeld/UnderpantsaetningLoesoerePaategn} endpoint with the specified XML payload,
     * message ID, and relates-to value.
     *
     * @param xmlPayload the XML payload containing the document to send in the request body
     * @param messageId the message {@link UUID} to include in the headers
     * @param relatesTo the {@code Relates-To} header value
     * @return the HTTP response containing the response body as a string
     * @throws HttpTimeoutException if a response isn't received within the time specified in the {@link ApiClientConfiguration configuration}
     * @throws IOException if any other I/O error occurs
     * @throws InterruptedException if the call has been canceled or the thread has been interrupted
     */
    public HttpResponse<String> postUnderpantsaetningLoesoerePaategn(
            String xmlPayload, String messageId, String relatesTo) throws IOException, InterruptedException {
        if (xmlPayload == null || messageId == null) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(MISSING_REQUIRED_PARAMETERS_ERROR);
        }

        HeaderValues customHeaderValue = new HeaderValues(messageId, relatesTo);

        return xmlApiHttpClient.sendPostRequest(
                "/PersonbogAnmeld/UnderpantsaetningLoesoerePaategn",
                xmlPayload,
                customHeaderValue,
                HttpResponse.BodyHandlers.ofString());
    }
}
