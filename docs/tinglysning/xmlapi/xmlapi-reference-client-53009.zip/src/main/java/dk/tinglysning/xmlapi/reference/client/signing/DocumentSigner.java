package dk.tinglysning.xmlapi.reference.client.signing;

import dk.tinglysning.xmlapi.reference.client.configurations.ApiClientConfiguration;
import java.security.InvalidAlgorithmParameterException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.*;
import javax.xml.crypto.dsig.*;
import javax.xml.crypto.dsig.dom.DOMSignContext;
import javax.xml.crypto.dsig.keyinfo.KeyInfo;
import javax.xml.crypto.dsig.keyinfo.KeyInfoFactory;
import javax.xml.crypto.dsig.keyinfo.X509Data;
import javax.xml.crypto.dsig.spec.C14NMethodParameterSpec;
import javax.xml.crypto.dsig.spec.TransformParameterSpec;
import javax.xml.crypto.dsig.spec.XPathFilterParameterSpec;
import lombok.RequiredArgsConstructor;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * A utility class responsible for digitally signing XML documents.
 *
 * <p>This class provides methods to sign XML documents with different key pairs:
 * <ul>
 *   <li>System certificates for standard document signing</li>
 *   <li>Non-repudiation certificates for legally binding signatures</li>
 *   <li>Role-specific signatures for 'Disponent' operations</li>
 * </ul>
 *
 * <p>All signing operations modify the provided {@link Document} in-place by adding
 * XML signature elements that comply with the XML Digital Signature specification.
 *
 */
@RequiredArgsConstructor
public class DocumentSigner {
    private static final TransformParameterSpec NO_TRANSFORM_PARAMETER = null;
    private static final String SIGNING_ERROR = "An error occurred during signing.";
    private static final String SIGNATURE_METHOD_RSA_SHA512 = "http://www.w3.org/2001/04/xmldsig-more#rsa-sha512";
    private final ApiClientConfiguration apiClientConfiguration;

    /**
     * XPath expression that defines which document elements should be excluded from
     * digital signatures.
     */
    private static final String XPATH_SUBSET_V2 = "not(ancestor-or-self::xpathds:Signature) and "
            + "not(ancestor-or-self::xpathanm:Procesinstruktion) and "
            + "not(ancestor-or-self::xpathanm:AnmelderInformation) and "
            + "not(ancestor-or-self::xpathmodel:TinglysningAfgift) and "
            + "not(ancestor-or-self::xpathmodel:AnmelderOrdningSamling) and "
            + "not(ancestor-or-self::xpathmodel:ForespoergselsIdentifikatorSamling) and "
            + "not(ancestor-or-self::xpathmodel:UnderskriftsmappeSignaturSamling) and "
            + "not(ancestor-or-self::xpathmodel:FuldmagtOrdningSamling) and "
            + "not(ancestor-or-self::xpathmodel:AktoerReference) and "
            + "not(ancestor-or-self::xpathmodel:SagsReference) and "
            + "not(ancestor-or-self::xpathxkom:EmailAddressIdentifier) and "
            + "not(ancestor-or-self::xpathmodel:UnderskriftIkkeNoedvendigIndikator)";

    private static final String NS_SCHEMA_XMLDSIG = "http://www.w3.org/2000/09/xmldsig#";
    private static final String NS_SCHEMA_ANMELDELSE_1 = "http://rep.oio.dk/tinglysning.dk/schema/anmeldelse/1/";
    private static final String NS_SCHEMA_MODEL_1 = "http://rep.oio.dk/tinglysning.dk/schema/model/1/";
    private static final String NS_XKOM = "http://rep.oio.dk/xkom.dk/xml/schemas/2005/03/15/";

    /**
     * Namespace prefix to URI mapping for XPath expressions used in selective signing.
     *
     * <p>This immutable map defines the namespace context required to evaluate XPath
     * expressions like {@link #XPATH_SUBSET_V2}. Each prefix corresponds to a specific
     * XML schema namespace used in Danish land registration documents:
     */
    private static final Map<String, String> XPATH_SUBSET_NS_MAP = Map.of(
            "xpathds", NS_SCHEMA_XMLDSIG,
            "xpathanm", NS_SCHEMA_ANMELDELSE_1,
            "xpathmodel", NS_SCHEMA_MODEL_1,
            "xpathxkom", NS_XKOM);

    /**
     * Signs the specified {@link Document} using the system key pair.
     * <p>
     * Intended for signing XML documents when searching for or retrieving data (for example, fetching car information).
     * </p>
     * <p>
     * This method creates an enveloped XML signature, embedding the signature directly into the existing document.
     * This method modifies the provided {@code Document} instance.
     * </p>
     *
     * @param document the XML document to be signed; must not be {@code null}
     * @throws IllegalStateException if an error occurs during signing
     */
    public void sign(Document document) {
        try {
            XMLSignature signature = createSignature(apiClientConfiguration.getSignCertificate());

            signature.sign(
                    new DOMSignContext(apiClientConfiguration.getSignPrivateKey(), document.getDocumentElement()));
        } catch (Exception e) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException(SIGNING_ERROR, e);
        }
    }

    /**
     * Signs the specified XML document using the company's non-repudiation certificate
     * and private key for legally binding signatures.
     * <p>
     * Intended for creating a new case that modifies existing data
     * (such as notifying about a property having a new owner).
     * </p>
     * <p>
     * Non-repudiation signatures provide stronger legal guarantees and are typically
     * used for documents that require proof of authenticity and integrity in legal contexts.
     * </p>
     * <p>
     * This method creates an enveloped XML signature that is embedded directly into the document.
     * This method modifies the provided {@code Document} instance.
     * </p>
     *
     * @param document the XML document to be signed; must not be {@code null}
     * @throws IllegalStateException if an error occurs during the signing process
     */
    public void signWithNonRepudiation(Document document) {
        try {
            // Create the Signature element containing information about the certificate etc.
            XMLSignature signature = createSignature(apiClientConfiguration.getSignCertificateNonRepudiation());

            // Sign the document. This inserts the finished Signature element.
            signature.sign(new DOMSignContext(
                    apiClientConfiguration.getSignPrivateKeyNonRepudiation(), document.getDocumentElement()));
        } catch (Exception exception) {
            throw new IllegalStateException(SIGNING_ERROR, exception);
        }
    }

    /**
     * Creates an {@link XMLSignature} element configured with the specified certificate
     *
     * @param certificate the X.509 certificate to include in the signature's KeyInfo element
     * @return a configured {@link XMLSignature} ready for signing
     * @throws InvalidAlgorithmParameterException if the signature algorithm parameters are invalid
     * @throws NoSuchAlgorithmException if the required cryptographic algorithms are not available
     */
    private static XMLSignature createSignature(X509Certificate certificate)
            throws InvalidAlgorithmParameterException, NoSuchAlgorithmException {
        XMLSignatureFactory signatureFactory = XMLSignatureFactory.getInstance("DOM");

        SignedInfo signedInfo = createSignedInfo(signatureFactory);
        KeyInfo keyInfo = createKeyInfo(signatureFactory, certificate);
        String signatureId = "Signature-" + UUID.randomUUID();

        return signatureFactory.newXMLSignature(signedInfo, keyInfo, null, signatureId, null);
    }

    /**
     * Creates the SignedInfo element for standard document signatures.
     *
     * <p>Configures the signature to use:
     * <ul>
     *   <li>Exclusive canonicalization method</li>
     *   <li>RSA-SHA512 signature algorithm</li>
     * </ul>
     *
     * @param signatureFactory the XML signature factory instance
     * @return a configured {@link SignedInfo} element
     * @throws NoSuchAlgorithmException if required algorithms are not available
     * @throws InvalidAlgorithmParameterException if algorithm parameters are invalid
     */
    private static SignedInfo createSignedInfo(XMLSignatureFactory signatureFactory)
            throws NoSuchAlgorithmException, InvalidAlgorithmParameterException {
        CanonicalizationMethod canonicalizationMethod = signatureFactory.newCanonicalizationMethod(
                CanonicalizationMethod.EXCLUSIVE, (C14NMethodParameterSpec) null);

        SignatureMethod signatureMethod = signatureFactory.newSignatureMethod(SIGNATURE_METHOD_RSA_SHA512, null);

        Reference reference = createReference(signatureFactory);
        List<Reference> list = Collections.singletonList(reference);

        return signatureFactory.newSignedInfo(canonicalizationMethod, signatureMethod, list);
    }

    /**
     * Creates a reference element that points to the entire document for signing.
     *
     * <p>The reference uses an empty URI to indicate the whole document should be signed,
     * with enveloped signature and exclusive canonicalization transformations as
     * required by E-TL specifications.
     *
     * @param signatureFactory the XML signature factory instance
     * @return a configured {@link Reference} element
     * @throws NoSuchAlgorithmException if digest algorithms are not available
     * @throws InvalidAlgorithmParameterException if transformation parameters are invalid
     */
    private static Reference createReference(XMLSignatureFactory signatureFactory)
            throws NoSuchAlgorithmException, InvalidAlgorithmParameterException {
        // An empty URI means that the whole document should be signed.
        String emptyUri = "";

        DigestMethod digestMethod = signatureFactory.newDigestMethod(DigestMethod.SHA256, null);

        // E-TL requires the transformations http://www.w3.org/2000/09/xmldsig#enveloped-signature and
        // http://www.w3.org/2001/10/xml-exc-c14n#.
        List<Transform> transforms = new ArrayList<>();
        transforms.add(signatureFactory.newTransform(Transform.ENVELOPED, NO_TRANSFORM_PARAMETER));
        transforms.add(signatureFactory.newTransform(CanonicalizationMethod.EXCLUSIVE, NO_TRANSFORM_PARAMETER));

        return signatureFactory.newReference(emptyUri, digestMethod, transforms, null, null);
    }

    /**
     * Creates a KeyInfo element containing the specified X.509 certificate.
     * @param signatureFactory the XML signature factory instance
     * @param certificate the X.509 certificate to embed in the KeyInfo
     * @return a configured {@link KeyInfo} element
     */
    private static KeyInfo createKeyInfo(XMLSignatureFactory signatureFactory, X509Certificate certificate) {
        KeyInfoFactory keyInfoFactory = signatureFactory.getKeyInfoFactory();
        X509Data x509Data = keyInfoFactory.newX509Data(Collections.singletonList(certificate));

        return keyInfoFactory.newKeyInfo(Collections.singletonList(x509Data));
    }

    /**
     * Signs the specified XML {@link Document} as a 'Disponent' using the non-repudiation certificate.
     * <p>
     * Intended for legally binding documents where a person acts on behalf of another individual or a company.
     * </p>
     * <p>
     * This method creates a role-specific signature for Disponent operations, using
     * XPath filtering to sign only specific parts of the document as defined by the
     * </p>
     * <p>
     * After signing, the document will contain a new {@code Signature} element.
     * This method modifies the provided {@code Document} instance.
     * </p>
     *
     * @param document the XML document to be signed; must not be {@code null}
     * @throws IllegalStateException if an error occurs during signing
     */
    public void signAsDisponent(Document document) {
        try {
            XMLSignature signature =
                    createSignatureForDisponent(apiClientConfiguration.getSignCertificateNonRepudiation());

            signature.sign(new DOMSignContext(
                    apiClientConfiguration.getSignPrivateKeyNonRepudiation(), document.getDocumentElement()));

            // without clearing whitespaces hash could be wrong and the signature invalid
            SigningUtil.removeWhitespaceFromLastSignature(document);
        } catch (Exception exception) {
            throw new IllegalStateException(SIGNING_ERROR, exception);
        }
    }

    /**
     * Signs the specified XML {@link Document} as a 'Disponent' using the system certificate.
     * <p>
     * Intended if youneed your sign to not be personal, company or system.
     * </p>
     * <p>
     * After signing, the document will contain a new {@code Signature} element.
     * This method modifies the provided {@code Document} instance.
     * </p>
     * @throws IllegalStateException if an error occurs during signing
     */
    public void signAsDisponentWithSystemCertificate(Document document) {
        try {
            XMLSignature signature = createSignatureForDisponent(apiClientConfiguration.getSignCertificate());

            signature.sign(
                    new DOMSignContext(apiClientConfiguration.getSignPrivateKey(), document.getDocumentElement()));

            // without clearing whitespaces hash could be wrong and the signature invalid
            SigningUtil.removeWhitespaceFromLastSignature(document);
        } catch (Exception exception) {
            throw new IllegalStateException(SIGNING_ERROR, exception);
        }
    }

    /**
     * Creates an XML signature element specifically configured for Disponent role signatures.
     *
     * @param certificate the X.509 certificate to include in the signature
     * @return a configured {@link XMLSignature} for Disponent operations
     * @throws InvalidAlgorithmParameterException if signature parameters are invalid
     * @throws NoSuchAlgorithmException if required algorithms are not available
     */
    private XMLSignature createSignatureForDisponent(X509Certificate certificate)
            throws InvalidAlgorithmParameterException, NoSuchAlgorithmException {
        XMLSignatureFactory signatureFactory = XMLSignatureFactory.getInstance("DOM");

        SignedInfo signedInfo = createSignedInfoForDisponent(signatureFactory);
        KeyInfo keyInfo = createKeyInfo(signatureFactory, certificate);
        String signatureId = "ID-DisponentSignatur-" + UUID.randomUUID();

        return signatureFactory.newXMLSignature(signedInfo, keyInfo, null, signatureId, null);
    }

    /**
     * Creates the SignedInfo element for Disponent role signatures.
     *
     * <p>Uses inclusive canonicalization (different from standard signatures)
     * and XPath-based document filtering for selective signing.
     * @param signatureFactory the XML signature factory instance
     * @return a configured {@link SignedInfo} for Disponent signatures
     * @throws NoSuchAlgorithmException if required algorithms are not available
     * @throws InvalidAlgorithmParameterException if algorithm parameters are invalid
     */
    private static SignedInfo createSignedInfoForDisponent(XMLSignatureFactory signatureFactory)
            throws NoSuchAlgorithmException, InvalidAlgorithmParameterException {
        CanonicalizationMethod canonicalizationMethod = signatureFactory.newCanonicalizationMethod(
                CanonicalizationMethod.INCLUSIVE, (C14NMethodParameterSpec) null);

        SignatureMethod signatureMethod = signatureFactory.newSignatureMethod(SIGNATURE_METHOD_RSA_SHA512, null);

        List<Reference> referenceList = new ArrayList<>();
        referenceList.add(createXpathReferenceForDisponent(signatureFactory));

        return signatureFactory.newSignedInfo(canonicalizationMethod, signatureMethod, referenceList);
    }

    /**
     * Creates a reference element with XPath filtering for Disponent signatures.
     *
     * <p>This reference uses XPath transformations to sign only document subsets matching the
     * configured XPath expression from the signature policy.
     *
     * @param signatureFactory the XML signature factory instance
     * @return a configured {@link Reference} with XPath filtering
     * @throws InvalidAlgorithmParameterException if XPath parameters are invalid
     * @throws NoSuchAlgorithmException if digest algorithms are not available
     */
    private static Reference createXpathReferenceForDisponent(XMLSignatureFactory signatureFactory)
            throws InvalidAlgorithmParameterException, NoSuchAlgorithmException {
        DigestMethod digestMethod = signatureFactory.newDigestMethod(DigestMethod.SHA256, null);

        List<Transform> transforms = new ArrayList<>();
        Transform excCanonicalization =
                signatureFactory.newTransform(CanonicalizationMethod.EXCLUSIVE, (TransformParameterSpec) null);

        XPathFilterParameterSpec spec = new XPathFilterParameterSpec(XPATH_SUBSET_V2, XPATH_SUBSET_NS_MAP);
        Transform transformXpath = signatureFactory.newTransform(Transform.XPATH, spec);
        transforms.add(transformXpath);
        transforms.add(excCanonicalization);

        return signatureFactory.newReference("", digestMethod, transforms, null, null);
    }

    /**
     * Adds XML namespace and schema location attributes to the root element of the provided {@link Document}.
     * <p>
     * This method performs the following actions:
     * <ul>
     *   <li>Sets the {@code xmlns:xsi} attribute to {@code "http://www.w3.org/2001/XMLSchema-instance"} on the root element.</li>
     *   <li>Sets the {@code xsi:schemaLocation} attribute using the root namespace and root document name:
     *       {@code [namespace] [namespace][rootTagName].xsd}</li>
     * </ul>
     * <p>
     * Example output:
     * <pre><code>
     * <EjendomOpret
     *   xmlns="http://rep.oio.dk/tinglysning.dk/service/message/tingbog/1/"
     *   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
     *   xsi:schemaLocation="http://rep.oio.dk/tinglysning.dk/service/message/tingbog/1/ http://rep.oio.dk/tinglysning.dk/service/message/tingbog/1/EjendomOpret.xsd">
     * </EjendomOpret>
     * </code></pre>
     * <p>
     *
     * @param document the XML {@link Document} whose root element will be modified to include namespace and schema location attributes
     */
    public static void addXmlNamespace(Document document) {
        Element root = document.getDocumentElement();
        root.setAttribute("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
        String namespace = root.getAttribute("xmlns");
        root.setAttribute("xsi:schemaLocation", String.format("%s %s%s.xsd", namespace, namespace, root.getTagName()));
    }
}
