package dk.tinglysning.xmlapi.reference.client.signing;

import javax.xml.crypto.dsig.XMLSignature;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Utility class for XML signature processing and whitespace normalization.
 * <p>
 * This class provides static methods to clean up whitespace from XML signature elements,
 * which is often necessary for proper signature validation and processing. The utility
 * focuses on removing unnecessary whitespace while preserving meaningful content.
 * </p>
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class SigningUtil {
    public static final String SIGNATURE_TAG_NAME = "Signature";

    /**
     * Removes whitespace from the last XML signature element found in the document.
     * <p>
     * This method locates all XML signature elements in the document using the
     * XMLSignature namespace and processes only the last one found. If no signature
     * elements are present, the method returns without performing any operations.
     * </p>
     *
     * @param document the XML document containing signature elements to process;
     *                 must not be null and must have a document element
     * @throws NullPointerException if the document parameter is null
     * @throws NullPointerException if the document has no document element
     * @see #removeWhitespaceFromElement(Node)
     */
    public static void removeWhitespaceFromLastSignature(Document document) {
        if (document == null || document.getDocumentElement() == null) {
            throw new NullPointerException("Document cannot be null");
        }

        NodeList nl = document.getDocumentElement().getElementsByTagNameNS(XMLSignature.XMLNS, SIGNATURE_TAG_NAME);
        if (nl.getLength() == 0) {
            return;
        }

        removeWhitespaceFromElement(nl.item(nl.getLength() - 1));
    }

    /**
     * Recursively removes whitespace from the specified XML element and all its children.
     * <p>
     * This method processes each child node of the given element in reverse order to
     * safely remove nodes during iteration:
     * </p>
     * <ul>
     * <li>Text nodes containing only whitespace are completely removed from the DOM</li>
     * <li>Text nodes with mixed content have tabs, carriage returns, and line feeds stripped</li>
     * <li>Element nodes are processed recursively</li>
     * <li>Other node types (comments, processing instructions, etc.) are ignored</li>
     * </ul>
     *
     * @param element the XML element from which to remove whitespace; must not be null
     */
    private static void removeWhitespaceFromElement(Node element) {
        NodeList children = element.getChildNodes();
        for (int j = (children.getLength() - 1); j >= 0; j--) {
            Node toTest = children.item(j);

            if (toTest.getNodeType() == Node.ELEMENT_NODE) {
                removeWhitespaceFromElement(toTest);
                continue;
            }

            if (toTest.getNodeType() == Node.TEXT_NODE) {
                if (toTest.getTextContent().isBlank()) {
                    element.removeChild(toTest);
                } else {
                    toTest.setTextContent(toTest.getTextContent().replaceAll("[\t\r\n]", ""));
                }
            }
        }
    }
}
