package dk.tinglysning.xmlapi.reference.client.signing;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class StringToDocumentMapper {
    /**
     * XML parser feature identifier for disabling DOCTYPE declaration processing.
     *
     * <p>This constant represents the Apache Xerces parser feature that prevents
     * processing of DOCTYPE declarations in XML documents. Enabling this feature
     * helps prevent XML External Entity (XXE) attacks and other security vulnerabilities
     * related to external entity processing.
     *
     * <p><strong>Security Note:</strong> It is recommended to enable this feature
     * when parsing untrusted XML content to prevent potential security exploits.
     *
     * @see <a href="https://owasp.org/www-community/vulnerabilities/XML_External_Entity_(XXE)_Processing">OWASP XXE Prevention</a>
     */
    public static final String DISABLE_DOCTYPE_DECLARATIONS = "http://apache.org/xml/features/disallow-doctype-decl";

    /**
     * Converts an XML string to a DOM Document object with security hardening enabled. To simplify reference client,
     * XML compliance with XSD is NOT checked. If that's needed, verification strategy should be considered.
     *
     * <p>This method parses the provided XML string using a securely configured
     * DocumentBuilder that prevents XXE attacks by disabling DOCTYPE declarations.
     * The resulting document is marked as standalone and uses UTF-8 encoding.
     * @param xml the XML string to parse; must be correct XML and not {@code null}
     * @return a DOM Document representation of the XML string, marked as standalone
     * @throws IllegalStateException if the XML cannot be parsed due to malformed syntax,
     *         parser configuration errors, I/O issues during parsing or if the xml parameter is {@code null}
     * @see Document#setXmlStandalone(boolean)
     */
    public static Document stringToDocument(String xml) {
        if (xml == null) {
            throw new IllegalStateException("Xml cannot be null");
        }
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setFeature(DISABLE_DOCTYPE_DECLARATIONS, true);
            factory.setNamespaceAware(true);

            byte[] bytes = xml.getBytes(StandardCharsets.UTF_8);
            Document doc = factory.newDocumentBuilder().parse(new ByteArrayInputStream(bytes));
            doc.setXmlStandalone(true);
            return doc;
        } catch (ParserConfigurationException | IOException | SAXException e) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException("Could not parse Xml to document", e);
        }
    }

    /**
     * Converts a DOM Document object to its XML string representation with security hardening.
     *
     * <p>This method serializes the provided Document using a securely configured
     * Transformer that prevents access to external resources and enables secure
     * processing features to protect against XML-based attacks.
     *
     * <p><strong>Output Format:</strong> The generated XML string preserves the document's
     * structure, attributes, and content. No additional formatting or indentation is applied.
     * @param document the DOM Document to serialize; must not be {@code null}
     * @return the XML string representation of the document
     * @throws IllegalStateException if the document cannot be serialized due to
     *         transformer configuration errors, transformation failures or if the document parameter is {@code null}
     * @see javax.xml.XMLConstants#FEATURE_SECURE_PROCESSING
     * @see javax.xml.XMLConstants#ACCESS_EXTERNAL_DTD
     * @see javax.xml.XMLConstants#ACCESS_EXTERNAL_STYLESHEET
     *
     */
    public static String documentToString(Document document) {
        if (document == null) {
            throw new IllegalStateException("Document cannot be null");
        }
        try {
            DOMSource domSource = new DOMSource(document);
            StringWriter writer = new StringWriter();
            StreamResult result = new StreamResult(writer);
            TransformerFactory tf = TransformerFactory.newInstance();
            tf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            tf.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
            tf.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, "");

            Transformer transformer = tf.newTransformer();
            transformer.transform(domSource, result);
            return writer.toString();
        } catch (TransformerException e) {
            // This reference implementation wraps exceptions in an IllegalStateException for simplicity.
            // Replace with appropriate error handling as needed.
            throw new IllegalStateException("Could not parse document to String", e);
        }
    }
}
