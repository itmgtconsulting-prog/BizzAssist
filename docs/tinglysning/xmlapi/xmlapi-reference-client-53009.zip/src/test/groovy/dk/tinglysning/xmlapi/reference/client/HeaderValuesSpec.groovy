package dk.tinglysning.xmlapi.reference.client

import spock.lang.Specification
import spock.lang.Unroll

class HeaderValuesSpec extends Specification {

    def "should create HeaderValues with messageUuid only"() {
        given:
        def messageUuid = "550e8400-e29b-41d4-a716-446655440000"

        when:
        def headerValues = new HeaderValues(messageUuid)

        then:
        headerValues.headers.size() == 2
        headerValues.headers.get(HeaderProvider.TINGLYSNING_MESSAGE_ID) == "uuid:550e8400-e29b-41d4-a716-446655440000"
        headerValues.headers.get(HeaderProvider.CONTENT_TYPE) == "application/xml"
        !headerValues.headers.containsKey(HeaderProvider.TINGLYSNING_RELATES_TO)
    }

    def "should create HeaderValues with messageUuid and relatesTo"() {
        given:
        def messageUuid = "550e8400-e29b-41d4-a716-446655440000"
        def relatesTo = "related-message-id"

        when:
        def headerValues = new HeaderValues(messageUuid, relatesTo)

        then:
        headerValues.headers.size() == 3
        headerValues.headers.get(HeaderProvider.TINGLYSNING_MESSAGE_ID) == "uuid:550e8400-e29b-41d4-a716-446655440000"
        headerValues.headers.get(HeaderProvider.CONTENT_TYPE) == "application/xml"
        headerValues.headers.get(HeaderProvider.TINGLYSNING_RELATES_TO) == relatesTo
    }

    def "should create HeaderValues with all parameters"() {
        given:
        def messageUuid = "550e8400-e29b-41d4-a716-446655440000"
        def relatesTo = "related-message-id"
        def contentType = "application/json"

        when:
        def headerValues = new HeaderValues(messageUuid, relatesTo, contentType)

        then:
        headerValues.headers.size() == 3
        headerValues.headers.get(HeaderProvider.TINGLYSNING_MESSAGE_ID) == "uuid:550e8400-e29b-41d4-a716-446655440000"
        headerValues.headers.get(HeaderProvider.TINGLYSNING_RELATES_TO) == relatesTo
        headerValues.headers.get(HeaderProvider.CONTENT_TYPE) == contentType
    }

    def "should create HeaderValues with null relatesTo in three-parameter constructor"() {
        given:
        def messageUuid = "550e8400-e29b-41d4-a716-446655440000"
        def contentType = "application/json"

        when:
        def headerValues = new HeaderValues(messageUuid, null, contentType)

        then:
        headerValues.headers.size() == 2
        headerValues.headers.get(HeaderProvider.TINGLYSNING_MESSAGE_ID) == "uuid:550e8400-e29b-41d4-a716-446655440000"
        headerValues.headers.get(HeaderProvider.CONTENT_TYPE) == contentType
        !headerValues.headers.containsKey(HeaderProvider.TINGLYSNING_RELATES_TO)
    }

    @Unroll
    def "should throw IllegalArgumentException when messageUuid is null"() {
        when:
        new HeaderValues(null)

        then:
        def exception = thrown(IllegalArgumentException)
        exception.message == "Message uuid and content type must not be null"
    }

    @Unroll
    def "should throw IllegalArgumentException when contentType is null"() {
        given:
        def messageUuid = "550e8400-e29b-41d4-a716-446655440000"

        when:
        new HeaderValues(messageUuid, "relatesTo", null)

        then:
        def exception = thrown(IllegalArgumentException)
        exception.message == "Message uuid and content type must not be null"
    }

    def "should throw IllegalArgumentException when both messageUuid and contentType are null"() {
        when:
        new HeaderValues(null, "relatesTo", null)

        then:
        def exception = thrown(IllegalArgumentException)
        exception.message == "Message uuid and content type must not be null"
    }

    def "should throw IllegalArgumentException when messageUuid is #issue"() {
        when:
        new HeaderValues(invalidUuid)

        then:
        thrown(IllegalArgumentException)

        where:
        invalidUuid | issue
        "invalid-uuid-format"                  | "not a uuid"
        "ce01bb-3479-4975-8ab5-cdb"            | "too short"
    }

    def "should format UUID correctly in message header"() {
        given:
        def messageUuid = "550e8400-e29b-41d4-a716-446655440000"
        def headerValues = new HeaderValues(messageUuid)

        when:
        def messageIdHeader = headerValues.headers.get(HeaderProvider.TINGLYSNING_MESSAGE_ID)

        then:
        messageIdHeader == "uuid:550e8400-e29b-41d4-a716-446655440000"
    }
}