package dk.tinglysning.xmlapi.reference.client

import dk.tinglysning.xmlapi.reference.client.configurations.ApiClientConfiguration
import spock.lang.Specification

import java.security.KeyStore
import java.security.KeyStoreException
import java.security.NoSuchAlgorithmException
import java.security.UnrecoverableKeyException

class SslContextFactorySpec extends Specification {

    static final ApiClientConfiguration appPropertiesValues = ApiClientConfiguration.getApiConfigWithAppProperties()

    def "should create SSL context successfully with configuration from properties"() {
        when:
        def result = SslContextFactory.createSslContext(appPropertiesValues)

        then:
        result.protocol == appPropertiesValues.getSslProtocol()
    }

    def "should throw IllegalStateException when provided invalid SSL protocol from properties"() {
        given:
        def configuration = appPropertiesValues.toBuilder().sslProtocol("non_existing_protocol").build()

        when:
        SslContextFactory.createSslContext(configuration)

        then:
        def exception = thrown(IllegalStateException)
        exception.message == "Unable to create SSL context"
        exception.cause instanceof NoSuchAlgorithmException
    }

    def "should throw IllegalStateException when there is unknown issue with loading keystore"() {
        given:
        def invalidKeyStore = KeyStore.getInstance("JKS")
        def configuration = appPropertiesValues.toBuilder().systemKeyStore(invalidKeyStore).build()

        when:
        SslContextFactory.createSslContext(configuration)

        then:
        def ex = thrown(IllegalStateException)
        ex.message == "Unable to create SSL context"
        ex.cause instanceof KeyStoreException
    }

    def "should throw IllegalStateException when provided the wrong password to correctly loaded keystore"() {
        given:
        def configuration = appPropertiesValues.toBuilder().systemKeystorePassword("wrong_password").build()

        when:
        SslContextFactory.createSslContext(configuration)

        then:
        def exception = thrown(IllegalStateException)
        exception.message == "Unable to create SSL context"
        exception.cause instanceof UnrecoverableKeyException
    }
}
