package dk.tinglysning.xmlapi.reference.client

import dk.tinglysning.xmlapi.reference.client.configurations.ApiClientConfiguration
import spock.lang.Shared
import spock.lang.Specification

import java.net.http.HttpClient
import java.net.http.HttpRequest
import java.net.http.HttpResponse

class XmlApiHttpClientSpec extends Specification {

    @Shared
    static ApiClientConfiguration apiClientConfiguration
    @Shared
    static XmlApiHttpClient s2sHttpClient

    @Shared
    static XmlApiHttpClient s2sWithMockedHttpClient
    final HttpClient mockHttpClient = Mock()

    @Shared
    static final endpoint = "/test-endpoint"
    @Shared
    static final messageUuid = "550e8400-e29b-41d4-a716-446655440000"
    @Shared
    static final headerValues = new HeaderValues(messageUuid)
    @Shared
    static final bodyHandler = HttpResponse.BodyHandlers.ofString()

    def setupSpec(){
        apiClientConfiguration = ApiClientConfiguration.getApiConfigWithAppProperties()
        s2sHttpClient = XmlApiHttpClientFactory.create(apiClientConfiguration)
    }

    def setup(){
        s2sWithMockedHttpClient = new XmlApiHttpClient(mockHttpClient, apiClientConfiguration)
    }

    def "should send GET request with correct parameters"() {
        given:
        def xmlPayload = "<xml>test</xml>"
        HttpResponse mockResponse = Mock()

        when:
        HttpResponse result = s2sWithMockedHttpClient.sendGetRequest(endpoint, xmlPayload, headerValues, bodyHandler)

        then:
        1 * mockHttpClient.send(_, bodyHandler) >> mockResponse
        result == mockResponse
    }

    def "should throw IllegalStateException when sendPostRequest provided with null"() {
        when:
        s2sWithMockedHttpClient.sendPostRequest(endpoint, xmlPayload, headerValues, bodyHandler)

        then:
        def exception = thrown(IllegalStateException)
        exception.getMessage() == "All values must be provided"

        where:
        endpoint | xmlPayload        | headerValues | bodyHandler
        null     | "<xml>test</xml>" | headerValues | bodyHandler
        endpoint | null              | headerValues | bodyHandler
        endpoint | "<xml>test</xml>" | null         | bodyHandler
        endpoint | "<xml>test</xml>" | headerValues | null
    }

    def "should throw IllegalStateException when sendGetRequest provided with null"() {
        when:
        s2sWithMockedHttpClient.sendGetRequest(endpoint, xmlPayload, headerValues, bodyHandler)

        then:
        def exception = thrown(IllegalStateException)
        exception.getMessage() == "All values must be provided"

        where:
        endpoint | xmlPayload        | headerValues | bodyHandler
        null     | "<xml>test</xml>" | headerValues | bodyHandler
        endpoint | null              | headerValues | bodyHandler
        endpoint | "<xml>test</xml>" | null         | bodyHandler
        endpoint | "<xml>test</xml>" | headerValues | null
    }

    def "should throw IOException when httpClient throws IOException on POST"() {
        given:
        def xmlPayload = "<xml>test</xml>"
        mockHttpClient.send(_ as HttpRequest, _ as HttpResponse.BodyHandler<Object>) >> { throw new IOException("Connection failed") }

        when:
        s2sWithMockedHttpClient.sendPostRequest(endpoint, xmlPayload, headerValues, bodyHandler)

        then:
        thrown(IOException)
    }

    def "should throw InterruptedException when httpClient throws InterruptedException on GET"() {
        given:
        def xmlPayload = "<xml>test</xml>"
        mockHttpClient.send(_ as HttpRequest, _ as HttpResponse.BodyHandler<Object>) >> { throw new InterruptedException("Request interrupted") }

        when:
        s2sWithMockedHttpClient.sendGetRequest(endpoint, xmlPayload, headerValues, bodyHandler)

        then:
        thrown(InterruptedException)
    }

    def "getHttpRequestBuilderWithHeaders should add all headers from HeaderValues to HttpRequest.Builder"() {
        given:
        def builder = HttpRequest.newBuilder(URI.create("https://example.com"))

        when:
        def builderWithHeaders = s2sHttpClient.getHttpRequestBuilderWithHeaders(builder, headerValues)

        then:
        checkIfHeadersAreCopiedToBuilder(builderWithHeaders,builder,headerValues)
    }

    def "should add headers correctly to HttpRequest builder"() {
        given:
        def relatesTo = "related-uuid"
        def headerValues = new HeaderValues(messageUuid, relatesTo, "text/plain")
        def builder = HttpRequest.newBuilder(URI.create("https://example.com"))

        when:
        def builderWithHeaders = XmlApiHttpClient.getHttpRequestBuilderWithHeaders(builder, headerValues)

        then:
        checkIfHeadersAreCopiedToBuilder(builderWithHeaders,builder,headerValues)
        noExceptionThrown()
    }

    def "should handle null relatesTo in HeaderValues"() {
        given:
        def headerValues = new HeaderValues(messageUuid, null, "text/plain")
        def builder = HttpRequest.newBuilder(URI.create("https://example.com"))

        when:
        def builderWithHeaders = XmlApiHttpClient.getHttpRequestBuilderWithHeaders(builder, headerValues)

        then:
        checkIfHeadersAreCopiedToBuilder(builderWithHeaders,builder,headerValues)
        noExceptionThrown()
    }


    def "should construct full URL correctly"() {
        given:
        def baseUrl = apiClientConfiguration.getBaseUrl()
        def xmlPayload = "<xml>test</xml>"

        when:
        s2sWithMockedHttpClient.sendPostRequest(endpoint, xmlPayload, headerValues, bodyHandler)

        then:
        1 * mockHttpClient.send({ HttpRequest request ->
            request.uri().toString() == baseUrl + endpoint
        }, bodyHandler)
    }


    private static checkIfHeadersAreCopiedToBuilder(HttpRequest.Builder result, HttpRequest.Builder builder, HeaderValues headerValues){
        result == builder
        def request = result.build()
        headerValues.getHeaders().each { key, value ->
            assert request.headers().firstValue(key).orElse(null) == value
        }
    }
}

