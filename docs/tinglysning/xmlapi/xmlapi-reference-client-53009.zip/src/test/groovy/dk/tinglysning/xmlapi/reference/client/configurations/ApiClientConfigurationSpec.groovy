package dk.tinglysning.xmlapi.reference.client.configurations

import spock.lang.Shared
import spock.lang.Specification

import java.security.KeyStore
import java.security.PrivateKey
import java.security.cert.X509Certificate

class ApiClientConfigurationSpec extends Specification {

    @Shared
    private static ApiClientConfiguration apiConfigWithAppProperties

    def setupSpec() {
        apiConfigWithAppProperties = ApiClientConfiguration.getApiConfigWithAppProperties()
    }

    def "should load properties from application.properties file"() {
        when:
        def apiConfigWithAppProperties = ApiClientConfiguration.getApiConfigWithAppProperties()

        then:
        noExceptionThrown()
        apiConfigWithAppProperties != null
    }

    def "should build ApiClientConfiguration with all properties using builder"() {
        given:
        def systemKeystorePath = "/path/to/system.p12"
        def systemKeystorePassword = "systemPassword"
        def systemKeystorekeyAlias = "systemAlias"
        def systemKeystoreType = KeystoreType.PKCS12

        def truststorePath = "/path/to/trust.p12"
        def truststorePassword = "trustPassword"
        def truststoreType = KeystoreType.PKCS12

        def companyKeystorePath = "/path/to/company.p12"
        def companyKeystorePassword = "companyPassword"
        def companyKeystorekeyAlias = "companyAlias"
        def companyKeystoreType = KeystoreType.PKCS12

        def systemKeyStore = Mock(KeyStore)
        def trustStore = Mock(KeyStore)
        def companyKeyStore = Mock(KeyStore)

        def signPrivateKey = Mock(PrivateKey)
        def signCertificate = Mock(X509Certificate)
        def signPrivateKeyNonRepudiation = Mock(PrivateKey)
        def signCertificateNonRepudiation = Mock(X509Certificate)

        def baseUrl = "https://api.example.com"
        def sslProtocol = "TLSv1.2"
        def connectTimeoutSeconds = 30
        def requestTimeoutSeconds = 60
        def properties = new Properties()

        when:
        def apiClientConfiguration = ApiClientConfiguration.builder()
                .systemKeystorePath(systemKeystorePath)
                .systemKeystorePassword(systemKeystorePassword)
                .systemKeystorekeyAlias(systemKeystorekeyAlias)
                .systemKeystoreType(systemKeystoreType)
                .truststorePath(truststorePath)
                .truststorePassword(truststorePassword)
                .truststoreType(truststoreType)
                .companyKeystorePath(companyKeystorePath)
                .companyKeystorePassword(companyKeystorePassword)
                .companyKeystorekeyAlias(companyKeystorekeyAlias)
                .companyKeystoreType(companyKeystoreType)
                .systemKeyStore(systemKeyStore)
                .trustStore(trustStore)
                .companyKeyStore(companyKeyStore)
                .signPrivateKey(signPrivateKey)
                .signCertificate(signCertificate)
                .signPrivateKeyNonRepudiation(signPrivateKeyNonRepudiation)
                .signCertificateNonRepudiation(signCertificateNonRepudiation)
                .baseUrl(baseUrl)
                .sslProtocol(sslProtocol)
                .connectTimeoutSeconds(connectTimeoutSeconds)
                .requestTimeoutSeconds(requestTimeoutSeconds)
                .properties(properties)
                .build()

        then:
        apiClientConfiguration.systemKeystorePath == systemKeystorePath
        apiClientConfiguration.systemKeystorePassword == systemKeystorePassword
        apiClientConfiguration.systemKeystorekeyAlias == systemKeystorekeyAlias
        apiClientConfiguration.systemKeystoreType == systemKeystoreType
        apiClientConfiguration.truststorePath == truststorePath
        apiClientConfiguration.truststorePassword == truststorePassword
        apiClientConfiguration.truststoreType == truststoreType
        apiClientConfiguration.companyKeystorePath == companyKeystorePath
        apiClientConfiguration.companyKeystorePassword == companyKeystorePassword
        apiClientConfiguration.companyKeystorekeyAlias == companyKeystorekeyAlias
        apiClientConfiguration.companyKeystoreType == companyKeystoreType
        apiClientConfiguration.systemKeyStore == systemKeyStore
        apiClientConfiguration.trustStore == trustStore
        apiClientConfiguration.companyKeyStore == companyKeyStore
        apiClientConfiguration.signPrivateKey == signPrivateKey
        apiClientConfiguration.signCertificate == signCertificate
        apiClientConfiguration.signPrivateKeyNonRepudiation == signPrivateKeyNonRepudiation
        apiClientConfiguration.signCertificateNonRepudiation == signCertificateNonRepudiation
        apiClientConfiguration.baseUrl == baseUrl
        apiClientConfiguration.sslProtocol == sslProtocol
        apiClientConfiguration.connectTimeoutSeconds == connectTimeoutSeconds
        apiClientConfiguration.requestTimeoutSeconds == requestTimeoutSeconds
        apiClientConfiguration.properties == properties
    }

    def "should create configuration from properties with all required values"() {
        given:
        def properties = new Properties()
        properties.setProperty("ssl.keystore.system.certificate.path", apiConfigWithAppProperties.systemKeystorePath)
        properties.setProperty("ssl.keystore.system.certificate.password", apiConfigWithAppProperties.systemKeystorePassword)
        properties.setProperty("ssl.keystore.system.certificate.key.alias", apiConfigWithAppProperties.systemKeystorekeyAlias)
        properties.setProperty("ssl.keystore.system.certificate.type", "PKCS12")

        properties.setProperty("ssl.truststore.path", apiConfigWithAppProperties.truststorePath)
        properties.setProperty("ssl.truststore.password", apiConfigWithAppProperties.truststorePassword)
        properties.setProperty("ssl.truststore.type", "PKCS12")

        properties.setProperty("ssl.keystore.company.certificate.path", apiConfigWithAppProperties.companyKeystorePath)
        properties.setProperty("ssl.keystore.company.certificate.password", apiConfigWithAppProperties.companyKeystorePassword)
        properties.setProperty("ssl.keystore.company.certificate.key.alias", apiConfigWithAppProperties.companyKeystorekeyAlias)
        properties.setProperty("ssl.keystore.company.certificate.type", "PKCS12")

        properties.setProperty("api.base-url", "https://api.test.com")
        properties.setProperty("ssl.protocol.type", "TLSv1.3")
        properties.setProperty("http.client.connect-timeout-seconds", "3")
        properties.setProperty("http.client.request-timeout-seconds", "7")

        when:
        def apiClientConfiguration = ApiClientConfiguration.getApiConfigWithProperties(properties)

        then:
        noExceptionThrown()
        apiClientConfiguration != null
    }

    def "should use default values when properties are missing or empty"() {
        given: "properties with missing optional values"
        def properties = new Properties()

        properties.setProperty("ssl.keystore.system.certificate.path", apiConfigWithAppProperties.systemKeystorePath)
        properties.setProperty("ssl.keystore.system.certificate.password", apiConfigWithAppProperties.systemKeystorePassword)
        properties.setProperty("ssl.keystore.system.certificate.key.alias", apiConfigWithAppProperties.systemKeystorekeyAlias)

        properties.setProperty("ssl.truststore.path", apiConfigWithAppProperties.truststorePath)
        properties.setProperty("ssl.truststore.password", apiConfigWithAppProperties.truststorePassword)

        properties.setProperty("ssl.keystore.company.certificate.path", apiConfigWithAppProperties.companyKeystorePath)
        properties.setProperty("ssl.keystore.company.certificate.password", apiConfigWithAppProperties.companyKeystorePassword)
        properties.setProperty("ssl.keystore.company.certificate.key.alias", apiConfigWithAppProperties.companyKeystorekeyAlias)

        properties.setProperty("api.base-url", "https://api.test.com")
        properties.setProperty("ssl.protocol.type", "TLSv1.3")

        when:
        def apiClientConfiguration = ApiClientConfiguration.getApiConfigWithProperties(properties)

        then: "should throw exception due to static method calls"
        noExceptionThrown()
        apiClientConfiguration.systemKeystoreType.name() == "PKCS12"
        apiClientConfiguration.truststoreType.name() == "PKCS12"
        apiClientConfiguration.companyKeystoreType.name() == "PKCS12"
        apiClientConfiguration.connectTimeoutSeconds == 2
        apiClientConfiguration.requestTimeoutSeconds == 6
    }

    def "should throw IllegalStateException when keystore operations fail"() {
        given:
        def properties = new Properties()
        properties.setProperty("ssl.keystore.system.certificate.path", "/invalid/path")
        properties.setProperty("ssl.keystore.system.certificate.password", "wrongPassword")
        properties.setProperty("ssl.keystore.system.certificate.key.alias", "invalidAlias")

        when:
        ApiClientConfiguration.getApiConfigWithProperties(properties)

        then:
        thrown(IllegalStateException)
    }

    def "toBuilder should create a new builder with existing values"() {
        given:
        def apiClientConfiguration = ApiClientConfiguration.builder()
                .systemKeystorePath("/test/path")
                .baseUrl("https://test.com")
                .connectTimeoutSeconds(30)
                .build()

        when:
        def modifiedConfig = apiClientConfiguration.toBuilder()
                .baseUrl("https://modified.com")
                .build()

        then:
        modifiedConfig.systemKeystorePath == "/test/path"
        modifiedConfig.baseUrl == "https://modified.com"
        modifiedConfig.connectTimeoutSeconds == 30
        apiClientConfiguration.baseUrl == "https://test.com"
    }
}
