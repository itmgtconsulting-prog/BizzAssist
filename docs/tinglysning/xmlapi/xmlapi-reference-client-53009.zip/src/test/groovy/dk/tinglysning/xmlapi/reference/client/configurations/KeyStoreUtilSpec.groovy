package dk.tinglysning.xmlapi.reference.client.configurations

import spock.lang.Specification
import java.lang.reflect.Modifier

class KeyStoreUtilSpec extends Specification {

    static final ApiClientConfiguration appPropertiesValues = ApiClientConfiguration.getApiConfigWithAppProperties()

    def "should successfully load keystore with valid parameters"() {
        given: "valid keystore parameters"
        def path = appPropertiesValues.getSystemKeystorePath()
        def password = appPropertiesValues.getSystemKeystorePassword()
        def type = appPropertiesValues.getTruststoreType()

        when:
        def keyStore = KeyStoreUtil.loadKeyStore(path, password, type)

        then: "keystore is loaded successfully"
        keyStore != null
    }

    def "should throw IllegalStateException when resource file does not exist"() {
        given:
        def path = "non-existent-keystore.jks"
        def password = "password123"
        def type = KeystoreType.JKS

        when:
        KeyStoreUtil.loadKeyStore(path, password, type)

        then:
        IllegalStateException exception = thrown(IllegalStateException)
        exception.message.contains("Resource not found")
        exception.message.contains(path)
    }

    def "should throw IllegalStateException when keystore type is invalid"() {
        given:
        String path = appPropertiesValues.getSystemKeystorePath()
        String password = appPropertiesValues.getSystemKeystorePassword()

        when:
        KeyStoreUtil.loadKeyStore(path, password, null)

        then:
        IllegalStateException exception = thrown(IllegalStateException)
        exception.message.contains("Could not open key store")
        exception.message.contains(path)
        exception.cause instanceof NullPointerException
    }

    def "should handle empty password when none is required"() {
        given:
        def path = "keystore_without_password.jks"
        def password = ""
        def type = KeystoreType.JKS

        when:
        def keystore = KeyStoreUtil.loadKeyStore(path, password, type)

        then:
        keystore != null
    }

    def "constructor should be private"() {
        when: "attempting to instantiate KeyStoreUtils"
        def constructor = KeyStoreUtil.class.getDeclaredConstructor()

        then: "constructor is private"
        constructor.modifiers & Modifier.PRIVATE

        and: "constructor is accessible after setAccessible(true)"
        constructor.setAccessible(true)
        constructor.newInstance() != null
    }
}

