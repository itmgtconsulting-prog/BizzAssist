package dk.tinglysning.xmlapi.reference.client.configurations

import spock.lang.Specification
import spock.lang.Unroll

class KeystoreTypeSpec extends Specification {

    @Unroll
    def "should have correct version for #enumValue"() {
        expect:
        enumValue.type == expectedVersion

        where:
        enumValue           | expectedVersion
        KeystoreType.JKS | "JKS"
        KeystoreType.PKCS12 | "PKCS12"
    }

    def "should return correct string representation for JKS"() {
        when:
        def jksType = KeystoreType.JKS

        then:
        jksType.toString() == "JKS"
        jksType.name() == "JKS"
        jksType.type == "JKS"
    }

    def "should return correct string representation for PKCS12"() {
        when:
        def pkcs12Type = KeystoreType.PKCS12

        then:
        pkcs12Type.toString() == "PKCS12"
        pkcs12Type.name() == "PKCS12"
        pkcs12Type.type == "PKCS12"
    }
}
