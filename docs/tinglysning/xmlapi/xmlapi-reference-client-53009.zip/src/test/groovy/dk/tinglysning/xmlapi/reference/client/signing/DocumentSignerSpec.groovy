package dk.tinglysning.xmlapi.reference.client.signing


import dk.tinglysning.xmlapi.reference.client.configurations.ApiClientConfiguration
import org.w3c.dom.Document
import org.w3c.dom.NodeList
import spock.lang.Shared
import spock.lang.Specification

import javax.xml.crypto.dsig.XMLSignature
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.cert.X509Certificate
import java.util.stream.Collectors

class DocumentSignerSpec extends Specification {

    Document parsedXmlDcument

    @Shared
    String xmlPayload
    @Shared
    ApiClientConfiguration apiClientConfiguration = ApiClientConfiguration.getApiConfigWithAppProperties()
    @Shared
    DocumentSigner documentSigner = new DocumentSigner(apiClientConfiguration)

    @Shared
    PrivateKey mockPrivateKey
    @Shared
    PrivateKey mockNonRepudiationPrivateKey
    @Shared
    ApiClientConfiguration mockConfig = Mock()
    @Shared
    X509Certificate mockCertificate = Mock()
    @Shared
    X509Certificate mockNonRepudiationCertificate = Mock()
    @Shared
    DocumentSigner mockDocumentSigner = new DocumentSigner(mockConfig)


    def setupSpec(){
        InputStream is = DocumentSignerSpec.class.getClassLoader().getResourceAsStream("AbonnementOpret/valid.xml")
        xmlPayload = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"))

        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA")
        keyGen.initialize(2048)
        KeyPair keyPair1 = keyGen.generateKeyPair()
        KeyPair keyPair2 = keyGen.generateKeyPair()

        mockPrivateKey = keyPair1.getPrivate()
        mockNonRepudiationPrivateKey = keyPair2.getPrivate()
    }

    def setup(){
        parsedXmlDcument = StringToDocumentMapper.stringToDocument(xmlPayload)
    }

    def "sign should add signature element to document"() {
        when:
        documentSigner.sign(parsedXmlDcument)

        then:
        NodeList signatures = parsedXmlDcument.getElementsByTagNameNS(XMLSignature.XMLNS, "Signature")
        signatures.getLength() == 1
        signatures.item(0).getAttributes().getNamedItem("Id").getNodeValue().startsWith("Signature-")
        NodeList signatureValue = parsedXmlDcument.getElementsByTagNameNS(XMLSignature.XMLNS, "SignatureValue")
        signatureValue.item(0).textContent.length() > 0
    }

    def "sign should throw IllegalStateException when signing fails"() {
        given:
        mockConfig.getSignPrivateKey() >> null
        mockConfig.getSignCertificate() >> mockCertificate

        when:
        mockDocumentSigner.sign(parsedXmlDcument)

        then:
        IllegalStateException ex = thrown()
        ex.getMessage() == "An error occurred during signing."
    }

    def "signWithNonRepudiation should add signature element to document"() {
        when:
        documentSigner.signWithNonRepudiation(parsedXmlDcument)

        then:
        NodeList signatures = parsedXmlDcument.getElementsByTagNameNS(XMLSignature.XMLNS, "Signature")
        signatures.getLength() == 1
        signatures.item(0).getAttributes().getNamedItem("Id").getNodeValue().startsWith("Signature-")
    }

    def "signWithNonRepudiation should throw IllegalStateException when signing fails"() {
        given:
        mockConfig.getSignPrivateKeyNonRepudiation() >> null
        mockConfig.getSignCertificateNonRepudiation() >> mockNonRepudiationCertificate

        when:
        mockDocumentSigner.signWithNonRepudiation(parsedXmlDcument)

        then:
        IllegalStateException ex = thrown()
        ex.getMessage() == "An error occurred during signing."
    }

    def "signAsDisponent should add signature element with correct ID prefix"() {
        when:
        documentSigner.signAsDisponent(parsedXmlDcument)

        then:
        NodeList signatures = parsedXmlDcument.getElementsByTagNameNS(XMLSignature.XMLNS, "Signature")
        signatures.getLength() == 1
        signatures.item(0).getAttributes().getNamedItem("Id").getNodeValue().startsWith("ID-DisponentSignatur-")
    }

    def "signAsDisponent should throw IllegalStateException when signing fails"() {
        given:
        mockConfig.getSignPrivateKeyNonRepudiation() >> null
        mockConfig.getSignCertificateNonRepudiation() >> mockNonRepudiationCertificate

        when:
        mockDocumentSigner.signAsDisponent(parsedXmlDcument)

        then:
        IllegalStateException ex = thrown()
        ex.getMessage() == "An error occurred during signing."
    }

    def "signAsDisponentWithSystemCertificate should add signature element with correct ID prefix"() {
        when:
        documentSigner.signAsDisponentWithSystemCertificate(parsedXmlDcument)

        then:
        NodeList signatures = parsedXmlDcument.getElementsByTagNameNS(XMLSignature.XMLNS, "Signature")
        signatures.getLength() == 1
        signatures.item(0).getAttributes().getNamedItem("Id").getNodeValue().startsWith("ID-DisponentSignatur-")
    }

    def "signAsDisponentWithSystemCertificate should throw IllegalStateException when signing fails"() {
        given:
        mockConfig.getSignPrivateKey() >> null
        mockConfig.getSignCertificate() >> mockCertificate

        when:
        mockDocumentSigner.signAsDisponentWithSystemCertificate(parsedXmlDcument)

        then:
        IllegalStateException ex = thrown()
        ex.getMessage() == "An error occurred during signing."
    }
}
