package dk.tinglysning.xmlapi.reference.client.signing


import org.w3c.dom.Document
import org.w3c.dom.Element
import org.w3c.dom.Node
import org.w3c.dom.Text
import spock.lang.Specification

import javax.xml.parsers.DocumentBuilder
import javax.xml.parsers.DocumentBuilderFactory

class SigningUtilSpec extends Specification {

    DocumentBuilder documentBuilder
    Document document

    def setup() {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance()
        factory.setNamespaceAware(true)
        documentBuilder = factory.newDocumentBuilder()
        document = documentBuilder.newDocument()
    }

    def "should not fail when document has no signature elements"() {
        given: "a document without signature elements"
        Element root = document.createElement("root")
        document.appendChild(root)

        when:
        SigningUtil.removeWhitespaceFromLastSignature(document)

        then:
        noExceptionThrown()
    }

    def "should throw NullPointerException when document is null"() {
        when:
        SigningUtil.removeWhitespaceFromLastSignature(null)

        then:
        thrown(NullPointerException)
    }

    def "should process only the last signature element when multiple exist"() {
        given: "a document with multiple signature elements"
        Element root = document.createElement("root")
        document.appendChild(root)

        Element firstSig = document.createElementNS("http://www.w3.org/2000/09/xmldsig#", "Signature")
        Text whitespace1 = document.createTextNode("   \n\t  ")
        firstSig.appendChild(whitespace1)
        root.appendChild(firstSig)

        Element secondSig = document.createElementNS("http://www.w3.org/2000/09/xmldsig#", "Signature")
        Text whitespace2 = document.createTextNode("   \n\t  ")
        secondSig.appendChild(whitespace2)
        root.appendChild(secondSig)

        when:
        SigningUtil.removeWhitespaceFromLastSignature(document)

        then: "only the last signature is cleaned"
        firstSig.getChildNodes().getLength() == 1
        secondSig.getChildNodes().getLength() == 0
    }

    def "should remove whitespace-only text nodes from signature element"() {
        given: "a signature element with whitespace-only text nodes"
        Element root = document.createElement("root")
        document.appendChild(root)

        Element signature = document.createElementNS("http://www.w3.org/2000/09/xmldsig#", "Signature")
        root.appendChild(signature)

        signature.appendChild(document.createTextNode("   "))
        signature.appendChild(document.createTextNode("\n\t\r"))
        signature.appendChild(document.createTextNode(" \n "))

        Element signedInfo = document.createElement("SignedInfo")
        signedInfo.appendChild(document.createTextNode("content"))
        signature.appendChild(signedInfo)

        when:
        SigningUtil.removeWhitespaceFromLastSignature(document)

        then: "whitespace-only nodes are removed but content is preserved"
        signature.getChildNodes().getLength() == 1
        signature.getFirstChild().getNodeName() == "SignedInfo"
        signature.getFirstChild().getTextContent() == "content"
    }

    def "should trim tab, CR, LF from mixed content text nodes"() {
        given: "a signature element with mixed content text nodes"
        Element root = document.createElement("root")
        document.appendChild(root)

        Element signature = document.createElementNS("http://www.w3.org/2000/09/xmldsig#", "Signature")
        root.appendChild(signature)

        Text mixedContent = document.createTextNode("Hello\tWorld\nTest\rContent")
        signature.appendChild(mixedContent)

        when:
        SigningUtil.removeWhitespaceFromLastSignature(document)

        then: "tabs, CR, and LF are removed but other content is preserved"
        signature.getFirstChild().getTextContent() == "HelloWorldTestContent"
    }

    def "should recursively process nested elements"() {
        given: "a signature element with nested structure and whitespace"
        Element root = document.createElement("root")
        document.appendChild(root)

        Element signature = document.createElementNS("http://www.w3.org/2000/09/xmldsig#", "Signature")
        root.appendChild(signature)

        Element signedInfo = document.createElement("SignedInfo")
        signature.appendChild(signedInfo)

        signedInfo.appendChild(document.createTextNode("   \n\t   "))

        Element canonMethod = document.createElement("CanonicalizationMethod")
        canonMethod.appendChild(document.createTextNode("Algorithm\tValue\n"))
        signedInfo.appendChild(canonMethod)

        when:
        SigningUtil.removeWhitespaceFromLastSignature(document)

        then: "nested elements are processed recursively"
        signedInfo.getChildNodes().getLength() == 1 // Whitespace-only node removed
        canonMethod.getTextContent() == "AlgorithmValue"
    }

    def "should handle empty signature element"() {
        given: "an empty signature element"
        Element root = document.createElement("root")
        document.appendChild(root)

        Element signature = document.createElementNS("http://www.w3.org/2000/09/xmldsig#", "Signature")
        root.appendChild(signature)

        when:
        SigningUtil.removeWhitespaceFromLastSignature(document)

        then:
        noExceptionThrown()
        signature.getChildNodes().getLength() == 0
    }

    def "should preserve regular spaces in mixed content"() {
        given: "a signature element with text containing regular spaces"
        Element root = document.createElement("root")
        document.appendChild(root)

        Element signature = document.createElementNS("http://www.w3.org/2000/09/xmldsig#", "Signature")
        root.appendChild(signature)

        Text textWithSpaces = document.createTextNode("Hello World Test\tContent\n")
        signature.appendChild(textWithSpaces)

        when:
        SigningUtil.removeWhitespaceFromLastSignature(document)

        then: "regular spaces are preserved but tabs and newlines are removed"
        signature.getFirstChild().getTextContent() == "Hello World TestContent"
    }

    def "should handle comments and processing instructions by ignoring them"() {
        given: "a signature element with comments and processing instructions"
        Element root = document.createElement("root")
        document.appendChild(root)

        Element signature = document.createElementNS("http://www.w3.org/2000/09/xmldsig#", "Signature")
        root.appendChild(signature)

        signature.appendChild(document.createComment("This is a comment"))
        signature.appendChild(document.createProcessingInstruction("target", "data"))
        signature.appendChild(document.createTextNode("   \n\t   "))

        when:
        SigningUtil.removeWhitespaceFromLastSignature(document)

        then: "comments and PIs are preserved, whitespace is removed"
        signature.getChildNodes().getLength() == 2
        signature.getFirstChild().getNodeType() == Node.COMMENT_NODE
        signature.getLastChild().getNodeType() == Node.PROCESSING_INSTRUCTION_NODE
    }
}
