package dk.tinglysning.xmlapi.reference.client.signing


import org.w3c.dom.Document
import org.w3c.dom.Element
import spock.lang.Specification
import spock.lang.Unroll

class StringToDocumentMapperSpec extends Specification {

    def "should convert valid XML string to Document"() {
        given:
        String xml = "<root><child>value</child></root>"

        when:
        Document document = StringToDocumentMapper.stringToDocument(xml)

        then: "document is created correctly"
        document != null
        document.xmlStandalone
        document.getDocumentElement().getNodeName() == "root"

        and: "child elements are preserved"
        def childNodes = document.getElementsByTagName("child")
        childNodes.getLength() == 1
        childNodes.item(0).getTextContent() == "value"
    }

    def "should convert Document back to XML string"() {
        given:
        String originalXml = "<root><child>value</child></root>"
        Document document = StringToDocumentMapper.stringToDocument(originalXml)

        when:
        String resultXml = StringToDocumentMapper.documentToString(document)

        then:
        resultXml != null
        resultXml.contains("<root>")
        resultXml.contains("<child>value</child>")
        resultXml.contains("</root>")
    }

    def "should handle XML with attributes and preserve child attributes"() {
        given:
        String xml = "<root id=\"123\" name=\"test\"><child attr=\"value\">content</child></root>"

        when:
        Document document = StringToDocumentMapper.stringToDocument(xml)

        then:
        document != null
        Element rootElement = document.getDocumentElement()
        rootElement.getAttribute("id") == "123"
        rootElement.getAttribute("name") == "test"

        and:
        Element childElement = (Element) document.getElementsByTagName("child").item(0)
        childElement.getAttribute("attr") == "value"
        childElement.getTextContent() == "content"
    }

    def "should handle XML with namespaces"() {
        given:
        String xml = "<ns:root xmlns:ns=\"http://example.com/namespace\">" +
                "<ns:child>value</ns:child>" +
                "</ns:root>"

        when:
        Document document = StringToDocumentMapper.stringToDocument(xml)

        then:
        document != null
        document.getDocumentElement().getNodeName() == "ns:root"
        document.getDocumentElement().getNamespaceURI() == "http://example.com/namespace"
    }

    def "should handle empty XML elements"() {
        given: "XML with empty elements"
        String xml = "<root><empty/><another></another></root>"

        when:
        Document document = StringToDocumentMapper.stringToDocument(xml)

        then: "empty elements are still present"
        document != null
        document.getDocumentElement().getChildNodes().getLength() == 2
    }

    def "should throw IllegalStateException for malformed XML"() {
        given:
        String malformedXml = "<root><child>unclosed tag</root>"

        when:
        StringToDocumentMapper.stringToDocument(malformedXml)

        then:
        IllegalStateException exception = thrown(IllegalStateException)
        exception.getMessage() == "Could not parse Xml to document"
        exception.getCause() != null
    }

    @Unroll
    def "should throw IllegalStateException for various malformed XML: #malformedXml"() {
        when:
        StringToDocumentMapper.stringToDocument(malformedXml)

        then:
        thrown(IllegalStateException)

        where:
        malformedXml << [
                "<root><child",
                "<root></child>",
                "<<root>>invalid</root>",
                "<root><child></root>",
                "not xml at all",
                "<root><unclosed>",
                "<root><child><grandchild></child></root>"
        ]
    }

    def "should handle XML with special characters"() {
        given:
        String xml = "<root><child>test&gt; &amp; &quot;quotes&quot;</child></root>"

        when:
        Document document = StringToDocumentMapper.stringToDocument(xml)
        String resultXml = StringToDocumentMapper.documentToString(document)

        then:
        document != null
        resultXml != null

        and:
        Element childElement = (Element) document.getElementsByTagName("child").item(0)
        childElement.getTextContent() == "test> & \"quotes\""
    }

    def "should handle round-trip conversion correctly"() {
        given:
        String originalXml = "<root id=\"123\"><child attr=\"value\">content</child><empty/></root>"

        when: "performing round-trip conversion"
        Document document = StringToDocumentMapper.stringToDocument(originalXml)
        String convertedXml = StringToDocumentMapper.documentToString(document)
        Document reconvertedDocument = StringToDocumentMapper.stringToDocument(convertedXml)

        then: "structure is preserved"
        document.getDocumentElement().getNodeName() == reconvertedDocument.getDocumentElement().getNodeName()
        document.getDocumentElement().getAttribute("id") == reconvertedDocument.getDocumentElement().getAttribute("id")

        and: "child elements are preserved"
        document.getElementsByTagName("child").getLength() == reconvertedDocument.getElementsByTagName("child").getLength()
        document.getElementsByTagName("empty").getLength() == reconvertedDocument.getElementsByTagName("empty").getLength()
    }

    def "should handle XML with CDATA sections"() {
        given:
        String xml = "<root><![CDATA[This is CDATA content with <special> characters]]></root>"

        when:
        Document document = StringToDocumentMapper.stringToDocument(xml)

        then:
        document != null
        document.getDocumentElement().getTextContent() == "This is CDATA content with <special> characters"
    }

    def "should handle XML with comments"() {
        given:
        String xml = "<root><!-- This is a comment --><child>value</child></root>"

        when:
        Document document = StringToDocumentMapper.stringToDocument(xml)

        then:
        document != null
        document.getDocumentElement().getNodeName() == "root"
        document.getElementsByTagName("child").getLength() == 1
    }

    def "should throw IllegalStateException when documentToString fails with null document"() {
        when:
        StringToDocumentMapper.documentToString(null)

        then:
        thrown(IllegalStateException)
    }

    def "should handle XML with multiple levels of nesting"() {
        given:
        String xml = "<level1><level2><level3><level4>deep content</level4></level3></level2></level1>"

        when:
        Document document = StringToDocumentMapper.stringToDocument(xml)

        then:
        document != null
        document.getDocumentElement().getNodeName() == "level1"

        and:
        def level4Nodes = document.getElementsByTagName("level4")
        level4Nodes.getLength() == 1
        level4Nodes.item(0).getTextContent() == "deep content"
    }

    def "should handle XML with mixed content"() {
        given:
        String xml = "<root>Text before<child>child content</child>Text after</root>"

        when:
        Document document = StringToDocumentMapper.stringToDocument(xml)

        then:
        document != null
        document.getDocumentElement().getNodeName() == "root"
        document.getElementsByTagName("child").getLength() == 1
        document.getElementsByTagName("child").item(0).getTextContent() == "child content"
    }

    def "should handle XML with multiple siblings"() {
        given:
        String xml = "<root><child1>value1</child1><child2>value2</child2><child3>value3</child3></root>"

        when:
        Document document = StringToDocumentMapper.stringToDocument(xml)

        then:
        document != null
        document.getElementsByTagName("child1").getLength() == 1
        document.getElementsByTagName("child2").getLength() == 1
        document.getElementsByTagName("child3").getLength() == 1

        and:
        document.getElementsByTagName("child1").item(0).getTextContent() == "value1"
        document.getElementsByTagName("child2").item(0).getTextContent() == "value2"
        document.getElementsByTagName("child3").item(0).getTextContent() == "value3"
    }

    def "should preserve XML declaration information through round-trip"() {
        given:
        String xml = "<root><child>abc</child></root>"

        when:
        def document = StringToDocumentMapper.stringToDocument(xml)
        String result = StringToDocumentMapper.documentToString(document)

        then: "document properties are maintained"
        result != null
        result.length() > 0
        document.xmlStandalone

    }

    def "should handle XML with numeric content"() {
        given:
        String xml = "<root><number>12345</number><decimal>123.45</decimal></root>"

        when:
        Document document = StringToDocumentMapper.stringToDocument(xml)

        then:
        document != null
        document.getElementsByTagName("number").item(0).getTextContent() == "12345"
        document.getElementsByTagName("decimal").item(0).getTextContent() == "123.45"
    }

    def "should handle XML with boolean-like content"() {
        given:
        String xml = "<root><flag1>true</flag1><flag2>false</flag2></root>"

        when:
        Document document = StringToDocumentMapper.stringToDocument(xml)

        then:
        document != null
        document.getElementsByTagName("flag1").item(0).getTextContent() == "true"
        document.getElementsByTagName("flag2").item(0).getTextContent() == "false"
    }

}
